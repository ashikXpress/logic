<?php $__env->startSection('content'); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">Candidate Evalution Information</h3>
            </div>

            <table class="table table-bordered">
                <thead>
                <tr>
                    <th style="font-size: 20px;" class="text-center" width="100%" scope="col">TRAINING INFORMATION</th>

                </tr>
                </thead>
            </table>

            <form class="form-horizontal" method="POST" enctype="multipart/form-data" action="<?php echo e(route('training_information_form',['candidate' => $candidate->id])); ?>">
                <?php echo csrf_field(); ?>

                <u><h4 class="text-center">Training Information</h4></u>
                <div class="box-body">

                    <div class="form-group <?php echo e($errors->has('training_title') ? 'has-error' :''); ?>">
                        <label class="col-md-2 control-label">Training Title </label>

                        <div class="col-md-4">
                            <input type="text" class="form-control" placeholder="Enter Training Title"
                                   name="training_title" value="<?php echo e(old('training_title')); ?>">

                            <?php $__errorArgs = ['training_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="help-block"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class=" <?php echo e($errors->has('training_institute') ? 'has-error' :''); ?>">
                            <label class="col-md-2 control-label">Training Institute </label>

                            <div class="col-md-4">
                                <input type="text" class="form-control" placeholder="Enter Training Institute"
                                       name="training_institute" value="<?php echo e(old('training_institute')); ?>">

                                <?php $__errorArgs = ['training_institute'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <div class="form-group <?php echo e($errors->has('training_certificate') ? 'has-error' :''); ?>">
                        <label class="col-md-2 control-label">Training Certificate image </label>

                        <div class="col-sm-4">
                            <input type="file" class="form-control" name="training_certificate">

                            <?php $__errorArgs = ['training_certificate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="help-block"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

                <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>

            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <!-- CK Editor -->
    <script src="<?php echo e(asset('themes/backend/bower_components/ckeditor/ckeditor.js')); ?>"></script>










    <script>

        var APP_URL = '<?php echo url()->full(); ?>';
        function getprint(prinarea_profile) {

            $('body').html($('#'+prinarea_profile).html());
            window.print();
            window.location.replace(APP_URL)
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\logic\resources\views/hr/training_information/form.blade.php ENDPATH**/ ?>