<?php $__env->startSection('style'); ?>
    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo e(asset('themes/backend/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    Employee Details
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <!-- Custom Tabs -->
            <div class="nav-tabs-custom">
                <ul class="nav nav-tabs">
                    <li class="active"><a href="#profile" data-toggle="tab">Profile</a></li>
                    <li><a href="#salary" data-toggle="tab">Salary</a></li>
                    <li><a href="#designation_log" data-toggle="tab">Designation Log</a></li>
                    <li><a href="#leave" data-toggle="tab">Leave</a></li>
                </ul>

                <div class="tab-content">

                    <div class="tab-pane active" id="profile">
                        <button class="pull-right btn btn-primary" onclick="getprint('prinarea_profile')">Print</button><br>

                        <div class="row" id="prinarea_profile">
                            <div class="col-md-8">
                                <table class="table table-bordered" >
                                    <tr>
                                        <th>Name</th>
                                        <td><?php echo e($employee->name); ?></td>
                                    </tr>

                                    <tr>
                                        <th>Employee ID</th>
                                        <td><?php echo e($employee->employee_id); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Category</th>
                                        <td>
                                            <?php if($employee->category_id == 1): ?>
                                                Dhaka Office
                                            <?php else: ?>
                                                Factory
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Date of Birth</th>
                                        <td>
                                            <?php if($employee->dob!=null): ?>
                                                <?php echo e($employee->dob->format('j F, Y')); ?>

                                            <?php endif; ?>
                                        </td>
                                    </tr>

                                    <tr>
                                        <th>Joining Date</th>
                                        <td>
                                            <?php if($employee->joining_date!=null): ?>
                                               <?php echo e($employee->joining_date->format('j F, Y')); ?>

                                            <?php endif; ?>


                                          </td>
                                    </tr>

                                    <tr>
                                        <th>Confirmation Date</th>

                                        <td>

                                            <?php if($employee->confirmation_date!=null): ?>
                                               <?php echo e($employee->confirmation_date->format('j F, Y')); ?>

                                            <?php endif; ?>

                                            </td>
                                    </tr>



                                    <tr>
                                        <th>Department</th>
                                        <td><?php echo e($employee->department->name); ?></td>
                                    </tr>

                                    <tr>
                                        <th>Designation</th>
                                        <td><?php echo e($employee->designation->name); ?></td>
                                    </tr>

                                    <tr>
                                        <th>Employee Type</th>
                                        <td>
                                            <?php if($employee->employee_type == 1): ?>
                                                Permanent
                                            <?php else: ?>
                                                Temporary
                                            <?php endif; ?>
                                        </td>
                                    </tr>

                                    <tr>
                                        <th>Reporting To</th>
                                        <td><?php echo e($employee->reporting_to); ?></td>
                                    </tr>

                                    <tr>
                                        <th>Gender</th>
                                        <td>
                                            <?php if($employee->gender == 1): ?>
                                                Male
                                            <?php else: ?>
                                                Female
                                            <?php endif; ?>
                                        </td>
                                    </tr>

                                    <tr>
                                        <th>Marital Status</th>
                                        <td>
                                            <?php if($employee->marital_status == 1): ?>
                                                Single
                                            <?php else: ?>
                                                Married
                                            <?php endif; ?>
                                        </td>
                                    </tr>

                                    <tr>
                                        <th>Mobile No.</th>
                                        <td><?php echo e($employee->mobile_no); ?></td>
                                    </tr>

                                    <tr>
                                        <th>Father Name</th>
                                        <td><?php echo e($employee->father_name); ?></td>
                                    </tr>

                                    <tr>
                                        <th>Mother Name</th>
                                        <td><?php echo e($employee->mother_name); ?></td>
                                    </tr>

                                    <tr>
                                        <th>Emergency Contact</th>
                                        <td><?php echo e($employee->emergency_contact); ?></td>
                                    </tr>

                                    <tr>
                                        <th>Present Address</th>
                                        <td><?php echo e($employee->present_address); ?></td>
                                    </tr>

                                    <tr>
                                        <th>Permanent Address</th>
                                        <td><?php echo e($employee->permanent_address); ?></td>
                                    </tr>

                                    <tr>
                                        <th>Email</th>
                                        <td><?php echo e($employee->email); ?></td>
                                    </tr>

                                    <tr>
                                        <th>Religion</th>
                                        <td>
                                            <?php if($employee->religion == 1): ?>
                                                Muslim
                                            <?php elseif($employee->religion == 2): ?>
                                                Hindu
                                            <?php elseif($employee->religion == 3): ?>
                                                Christian
                                            <?php elseif($employee->religion == 4): ?>
                                                Other
                                            <?php endif; ?>
                                        </td>
                                    </tr>

                                    <tr>
                                        <th>Bank Name</th>
                                        <td><?php echo e($employee->bank_name); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Bank Branch</th>
                                        <td><?php echo e($employee->bank_branch); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Bank Account</th>
                                        <td><?php echo e($employee->bank_account); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Gross Salary</th>
                                        <td><?php echo e(number_format($employee->gross_salary,2)); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Previous Salary</th>
                                        <td><?php echo e(number_format($employee->previous_salaray,2)); ?></td>
                                    </tr>


                                </table>
                            </div>

                            <div class="col-md-4 text-center">
                                <?php if($employee->photo): ?>
                                <img class="img-thumbnail" src="<?php echo e(asset($employee->photo)); ?>" width="150px"> <br><br>
                                <?php endif; ?>
                                <?php if($employee->signature): ?>

                                    <img class="img-thumbnail" src="<?php echo e(asset($employee->signature)); ?>" width="150px"> <br><br>
                                <?php endif; ?>

                                <?php if($employee->cv): ?>
                                    <a href="<?php echo e(asset($employee->cv)); ?>" class="btn btn-primary btn-sm" download>Download CV</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <!-- /.tab-pane -->

                    <div class="tab-pane" id="salary">

                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <tr>
                                    <th>Basic Salary</th>
                                    <td>৳<?php echo e($employee->basic_salary); ?></td>
                                </tr>
                                <tr>
                                    <th>House Rent</th>
                                    <td>৳<?php echo e($employee->house_rent); ?></td>
                                </tr>
                                <tr>
                                    <th>Travel</th>
                                    <td>৳<?php echo e($employee->travel); ?></td>
                                </tr>
                                <tr>
                                    <th>Medical</th>
                                    <td>৳<?php echo e($employee->medical); ?></td>
                                </tr>
                                <tr>
                                    <th>Tax</th>
                                    <td>৳<?php echo e($employee->tax); ?></td>
                                </tr>
                                <tr>
                                    <th>Others Deduct</th>
                                    <td>৳<?php echo e($employee->others_deduct); ?></td>
                                </tr>
                                <tr>
                                    <th>Gross Salary</th>
                                    <th>৳<?php echo e($employee->gross_salary); ?></th>
                                </tr>
                            </table>
                        </div>
                        <button class="pull-right btn btn-primary" onclick="getprint('prinarea_salary')">Print</button><br>

                        <div id="prinarea_salary">
                            <div class="table-responsive">
                                <table class="table no-margin">
                                    <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Type</th>
                                        <th>Basic Salary</th>
                                        <th>House Rent</th>
                                        <th>Travel</th>
                                        <th>Medical</th>
                                        <th>Tax</th>
                                        <th>Others Deduct</th>
                                        <th>Gross Salary</th>
                                    </tr>
                                    </thead>

                                    <tbody>
                                    <?php $__currentLoopData = $employee->salaryChangeLog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($log->date->format('j F, Y')); ?></td>
                                            <td>
                                                <?php if($log->type == 1): ?>
                                                    Confirmation
                                                <?php elseif($log->type == 2): ?>
                                                    Yearly Increment
                                                <?php elseif($log->type == 3): ?>
                                                    Promotion
                                                <?php elseif($log->type == 4): ?>
                                                    Other
                                                <?php elseif($log->type == 5): ?>
                                                    Initial
                                                <?php endif; ?>
                                            </td>
                                            <td>৳<?php echo e($log->basic_salary); ?></td>
                                            <td>৳<?php echo e($log->house_rent); ?></td>
                                            <td>৳<?php echo e($log->travel); ?></td>
                                            <td>৳<?php echo e($log->medical); ?></td>
                                            <td>৳<?php echo e($log->tax); ?></td>
                                            <td>৳<?php echo e($log->others_deduct); ?></td>
                                            <td>৳<?php echo e($log->gross_salary); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>


                    </div>
                    <!-- /.tab-pane -->

                    <div class="tab-pane" id="designation_log">
                        <div class="table-responsive">
                            <table class="table no-margin">
                                <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Department</th>
                                    <th>Designation</th>
                                </tr>
                                </thead>

                                <tbody>
                                <?php $__currentLoopData = $employee->designationLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>

                                            <?php if($log->date!=null): ?>
                                                <?php echo e($log->date->format('j F, Y')); ?>

                                            <?php endif; ?>
                                            </td>
                                        <td><?php echo e($log->department->name); ?></td>
                                        <td><?php echo e($log->designation->name); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- /.tab-pane -->

                    <div class="tab-pane" id="leave">
                        <button class="pull-right btn btn-primary" onclick="getprintleave('prinarea_leave')">Print</button><br>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="box" style="border: 0px solid">
                                    <div class="box-header with-border">
                                        <h3 class="box-title">Filter</h3>
                                    </div>
                                    <!-- /.box-header -->

                                    <div class="box-body">
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label>Year</label>

                                                    <select class="form-control" id="leave-year">
                                                        <?php for($i=2020; $i <= date('Y'); $i++): ?>
                                                            <option value="<?php echo e($i); ?>" <?php echo e($i == date('Y') ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                                                        <?php endfor; ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div id="prinarea_leave">
                            <div class="table-responsive " id="leave-table" >
                                <table class="table table-bordered">
                                    <thead>
                                    <tr>
                                        <th>Type</th>
                                        <th>From</th>
                                        <th>To</th>
                                        <th>Days</th>
                                        <th>Note</th>
                                    </tr>
                                    </thead>

                                    <tbody>
                                    <?php $__currentLoopData = $leaves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php if($leave->type == 1): ?>
                                                    Annual
                                                <?php elseif($leave->type == 2): ?>
                                                    Casual
                                                <?php elseif($leave->type == 3): ?>
                                                    Sick
                                                <?php elseif($leave->type == 4): ?>
                                                    Others
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($leave->from->format('j F, Y')); ?></td>
                                            <td><?php echo e($leave->to->format('j F, Y')); ?></td>
                                            <td><?php echo e($leave->total_days); ?></td>
                                            <td><?php echo e($leave->note); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>

                                    <tfoot>
                                    <tr>
                                        <th colspan="3">Total Days</th>
                                        <th><?php echo e($leaves->sum('total_days')); ?></th>
                                        <th></th>
                                    </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>

                    </div>
                    <!-- /.tab-pane -->
                </div>
                <!-- /.tab-content -->
            </div>
            <!-- nav-tabs-custom -->
        </div>
        <!-- /.col -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- DataTables -->
    <script src="<?php echo e(asset('themes/backend/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('themes/backend/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>

    <script>
        $(function () {
            $('#leave-year').change(function () {
                var year = $(this).val();
                var employeeId = '<?php echo e($employee->id); ?>';

                $.ajax({
                    method: "POST",
                    url: "<?php echo e(route('employee.get_leaves')); ?>",
                    data: { year: year, employeeId: employeeId }
                }).done(function( response ) {
                    $('#leave-table').html(response.html);
                });
            });
        })
    </script>
    <script>

        var APP_URL = '<?php echo url()->full(); ?>';
        function getprint(prinarea_profile) {

            $('body').html($('#'+prinarea_profile).html());
            window.print();
            window.location.replace(APP_URL)
        }
        function getprintleave(prinarea_leave) {

            $('body').html($('#'+prinarea_leave).html());
            window.print();
            window.location.replace(APP_URL)
        }
        function getprintleave(prinarea_salary) {

            $('body').html($('#'+prinarea_salary).html());
            window.print();
            window.location.replace(APP_URL)
        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\logic_group\resources\views/hr/employee/details.blade.php ENDPATH**/ ?>