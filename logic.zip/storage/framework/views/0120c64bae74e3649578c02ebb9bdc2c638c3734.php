<?php $__env->startSection('style'); ?>
    <!-- bootstrap datepicker -->
    <link rel="stylesheet" href="<?php echo e(asset('themes/backend/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    Candidate Form
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    kkbjvhg

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\logic_group\resources\views/hr/evalution/candidate_evalution_form.blade.php ENDPATH**/ ?>
