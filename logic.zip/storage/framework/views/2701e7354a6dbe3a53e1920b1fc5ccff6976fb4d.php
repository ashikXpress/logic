<?php $__env->startSection('content'); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">Candidate Job Information</h3>
            </div>

            <table class="table table-bordered">
                <thead>
                <tr>
                    <th style="font-size: 20px;" class="text-center" width="100%" scope="col">Job INFORMATION</th>

                </tr>
                </thead>
            </table>
            <u><h4 class="text-center">Add Previous Job Information</h4></u>

            <form class="form-horizontal" method="POST" enctype="multipart/form-data" action="<?php echo e(route('job_information_form',['candidate' => $candidate->id])); ?>">
                <?php echo csrf_field(); ?>

                <div class="box-body">

                    <div class="form-group <?php echo e($errors->has('previous_company_name') ? 'has-error' :''); ?>">
                        <label class="col-md-3 control-label"> Previous Company Name</label>

                        <div class="col-md-9">
                            <input type="text" class="form-control" placeholder="Previous Company Name"
                                   name="previous_company_name" value="<?php echo e(old('previous_company_name')); ?>">

                            <?php $__errorArgs = ['previous_company_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="help-block"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group <?php echo e($errors->has('previous_company_designation') ? 'has-error' :''); ?>">
                        <label class="col-md-3 control-label">Previous Company Designation </label>

                        <div class="col-md-9">
                            <input type="text" class="form-control" placeholder="Enter Previous Company Designation"
                                   name="previous_company_designation" value="<?php echo e(old('previous_company_designation')); ?>">

                            <?php $__errorArgs = ['previous_company_designation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="help-block"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group <?php echo e($errors->has('from') ? 'has-error' :''); ?>">

                        <label class="col-md-3 control-label">Previous Job Duration From </label>

                        <div class="col-md-3">
                            <input type="date" class="form-control job-duration" id="from"
                                   name="from" value="<?php echo e(old('from"')); ?>">

                            <?php $__errorArgs = ['from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="help-block"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <label class="col-md-1 control-label">Duration To </label>
                        <div class="col-md-3">
                            <input type="date" class="form-control job-duration" id="to"
                                   name="to" value="<?php echo e(old('to"')); ?>">

                            <?php $__errorArgs = ['to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="help-block"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-md-2">
                            <input type="text" class="form-control total-duration" placeholder="Total Duration" id="total-duration"
                                   name="total_duration">

                            <?php $__errorArgs = ['total_duration'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="help-block"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group <?php echo e($errors->has('major_responsibility') ? 'has-error' :''); ?>">
                        <label class="col-sm-3 control-label">Major Responsibility</label>

                        <div class="col-md-9">
                            <input type="text" class="form-control" placeholder="Enter Major Responsibility"
                                   name="major_responsibility" value="<?php echo e(old('major_responsibility')); ?>">

                            <?php $__errorArgs = ['major_responsibility'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="help-block"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group <?php echo e($errors->has('experience_certificate') ? 'has-error' :''); ?>">
                        <label class="col-md-3 control-label">Experience Certificate Image </label>

                        <div class="col-sm-9">
                            <input type="file" class="form-control" name="experience_certificate">

                            <?php $__errorArgs = ['experience_certificate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="help-block"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

                <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>

            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <!-- CK Editor -->
    <script src="<?php echo e(asset('themes/backend/bower_components/ckeditor/ckeditor.js')); ?>"></script>
    <script src="<?php echo e(asset('themes/backend/js/moment.min.js')); ?>"></script>

    <script>

        $(".job-duration").change(function(){

            var a = moment(document.getElementById("from").value);
            var b = moment(document.getElementById("to").value);
            var diffDays = b.diff(a, 'days');

            var days = diffDays;
            var calculateTimimg = d => {
                let months = 0, years = 0, days = 0, weeks = 0;
                while(d){
                    if(d >= 365){
                        years++;
                        d -= 365;
                    }else if(d >= 30){
                        months++;
                        d -= 30;
                    // }else if(d >= 7){
                    //     weeks++;
                    //     d -= 7;
                    }else{
                        days++;
                        d--;
                    }
                };
                return {
                    years, months, days
                };
            };
            var total = calculateTimimg(days).years+ '  ' +"Years"+ '  ' + calculateTimimg(days).months+ '  ' +"Months"+ '  ' +calculateTimimg(days).days+ '  ' +"Days";
            document.getElementById("total-duration").value = total;

        });
    </script>

    <script>

        var APP_URL = '<?php echo url()->full(); ?>';
        function getprint(prinarea_profile) {

            $('body').html($('#'+prinarea_profile).html());
            window.print();
            window.location.replace(APP_URL)
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\logic\resources\views/hr/job_information/form.blade.php ENDPATH**/ ?>