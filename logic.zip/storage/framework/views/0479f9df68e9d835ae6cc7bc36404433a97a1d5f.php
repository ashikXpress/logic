<?php $__env->startSection('style'); ?>
    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo e(asset('themes/backend/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    Sale Receipt Details
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-body">
                    <div class="row">
                        <div class="col-md-12 text-right">
                            <a target="_blank" href="<?php echo e(route('sale_receipt.print', ['order' => $order->id])); ?>" class="btn btn-primary">Print</a>
                        </div>
                    </div>

                    <hr>

                    <div class="row">
                        <div class="col-md-6">
                            <table class="table table-bordered">
                                <tr>
                                    <th>Order No.</th>
                                    <td><?php echo e($order->order_no); ?></td>
                                </tr>
                                <tr>
                                    <th>Order Date</th>
                                    <td><?php echo e($order->date->format('j F, Y')); ?></td>
                                </tr>
                                <tr>
                                    <th>Next Payment Date</th>
                                    <td><?php echo e($order->next_payment ? $order->next_payment->format('j F, Y') : ''); ?></td>
                                </tr>
                            </table>
                        </div>

                        <div class="col-md-6">
                            <table class="table table-bordered">
                                <tr>
                                    <th colspan="2" class="text-center">Buyer Info</th>
                                </tr>
                                <tr>
                                    <th>Sister Concern</th>
                                    <td><?php echo e($order->sisterConcern->name); ?></td>
                                </tr>
                                <tr>
                                    <th>Client</th>
                                    <td><?php echo e($order->client->name); ?></td>
                                </tr>
                                <tr>
                                    <th>Mobile No.</th>
                                    <td><?php echo e($order->client->mobile_no); ?></td>
                                </tr>
                                <tr>
                                    <th>Email</th>
                                    <td><?php echo e($order->client->email); ?></td>
                                </tr>
                                <tr>
                                    <th>Address</th>
                                    <td><?php echo e($order->client->address); ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>

                    <?php if(count($order->products) > 0): ?>
                        <div class="row">
                            <div class="col-md-12">
                                <table class="table table-bordered table-striped">
                                    <thead>
                                    <tr>
                                        <th>Product Name</th>
                                        <th>Quantity</th>
                                        <th>Unit Price</th>
                                        <th>Total</th>
                                    </tr>
                                    </thead>

                                    <tbody>
                                    <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($product->pivot->product_name); ?></td>
                                            <td><?php echo e($product->pivot->quantity); ?></td>
                                            <td>৳<?php echo e(number_format($product->pivot->unit_price, 2)); ?></td>
                                            <td>৳<?php echo e(number_format($product->pivot->total, 2)); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    <?php endif; ?>

                    <div class="row">
                        <div class="col-md-offset-8 col-md-4">
                            <table class="table table-bordered">
                                <tr>
                                    <th>Sub Total</th>
                                    <td>৳<?php echo e(number_format($order->sub_total, 2)); ?></td>
                                </tr>
                                <tr>
                                    <th>Vat (<?php echo e($order->vat_percentage); ?>%)</th>
                                    <td>৳<?php echo e(number_format($order->vat, 2)); ?></td>
                                </tr>
                                <tr>
                                    <th>Discount</th>
                                    <td>৳<?php echo e(number_format($order->discount, 2)); ?></td>
                                </tr>
                                <tr>
                                    <th>Total</th>
                                    <td>৳<?php echo e(number_format($order->total, 2)); ?></td>
                                </tr>
                                <tr>
                                    <th>Paid</th>
                                    <td>৳<?php echo e(number_format($order->paid, 2)); ?></td>
                                </tr>
                                <tr>
                                    <th>Due</th>
                                    <td>৳<?php echo e(number_format($order->due, 2)); ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-12">
                            <table id="table-payments" class="table table-bordered table-striped">
                                <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Type</th>
                                    <th>Transaction Method</th>
                                    <th>Bank</th>
                                    <th>Branch</th>
                                    <th>Account</th>
                                    <th>Amount</th>
                                    <th>Note</th>
                                    <th>Action</th>
                                </tr>
                                </thead>

                                <tbody>
                                <?php $__currentLoopData = $order->payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($payment->date->format('Y-m-d')); ?></td>
                                        <td>
                                            <?php if($payment->type == 1): ?>
                                                Pay
                                            <?php elseif($payment->type == 2): ?>
                                                Refund
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($payment->transaction_method == 1): ?>
                                                Cash
                                            <?php elseif($payment->transaction_method == 3): ?>
                                                Mobile Banking
                                            <?php else: ?>
                                                Bank
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($payment->bank ? $payment->bank->name : ''); ?></td>
                                        <td><?php echo e($payment->branch ? $payment->branch->name : ''); ?></td>
                                        <td><?php echo e($payment->account ? $payment->account->account_no : ''); ?></td>
                                        <td>৳<?php echo e(number_format($payment->amount, 2)); ?></td>
                                        <td><?php echo e($payment->note); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('sale_receipt.payment_details', ['payment' => $payment->id])); ?>" class="btn btn-primary btn-sm">Details</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- DataTables -->
    <script src="<?php echo e(asset('themes/backend/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('themes/backend/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>

    <script>
        $(function () {
            $('#table-payments').DataTable({
                "order": [[ 0, "desc" ]],
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\logic_new\resources\views/sale/receipt/details.blade.php ENDPATH**/ ?>