<?php $__env->startSection('style'); ?>
    <!-- bootstrap datepicker -->
    <link rel="stylesheet" href="<?php echo e(asset('themes/backend/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>">
    <!-- Select2 -->
    <link rel="stylesheet" href="<?php echo e(asset('themes/backend/bower_components/select2/dist/css/select2.min.css')); ?>">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    Create Loan
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(Session::has('message')): ?>
        <div class="alert alert-success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <?php echo e(Session::get('message')); ?>

        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Create Loan</h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <form class="form-horizontal" method="POST" enctype="multipart/form-data" action="<?php echo e(route('payroll.create.pf_loan')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="box-body">
                        <div class="form-group <?php echo e($errors->has('employee_id') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Employee ID(Loan Give)*</label>

                            <div class="col-sm-10">
                                <select class="form-control select2" name="employee_id" id="employee_id">
                                    <option value="">Select Employee Id</option>
                                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php echo e($employee->id == request()->get('employee_id') ? 'selected' : ''); ?> value="<?php echo e($employee->id); ?>"><?php echo e($employee->name); ?>-<?php echo e($employee->employee_id); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                                <?php $__errorArgs = ['employee_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('amount') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Amount *</label>

                            <div class="col-sm-10">
                                <input type="text" class="form-control" name="amount" placeholder="Enter Amount" value="<?php echo e(old('amount')); ?>">

                                <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('interest') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Interest *</label>

                            <div class="col-sm-10">
                                <input type="text" class="form-control" name="interest" placeholder="%" value="<?php echo e(old('interest')); ?>">

                                <?php $__errorArgs = ['interest'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('installment_month') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Installment Month *</label>

                            <div class="col-sm-10">
                                <select name="installment_month" class="form-control" placeholder="Enter Installment Month" value="<?php echo e(old('installment_month')); ?>">
                                    <option value=" "> Select Month </option>
                                    <option value="3">Three Month</option>
                                    <option value="6">Six Month</option>
                                    <option value="9">Nine Month</option>
                                    <option value="12">Twelve Month</option>
                                    <option value="15">Fifteen Month</option>
                                    <option value="18">Eighteen Month</option>
                                    <option value="21">Twenty One Month</option>
                                    <option value="24">Twenty Four Month</option>
                                </select>

                                <?php $__errorArgs = ['installment_month'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('pf_loan_date') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Loan Date *</label>

                            <div class="col-sm-10">
                                <div class="input-group date">
                                    <div class="input-group-addon">
                                        <i class="fa fa-calendar"></i>
                                    </div>
                                    <input type="text" class="form-control pull-right" id="date" name="pf_loan_date" value="<?php echo e(empty(old('pf_loan_date')) ? ($errors->has('pf_loan_date') ? '' : date('Y-m-d')) : old('pf_loan_date')); ?>" autocomplete="off">
                                </div>
                                <!-- /.input group -->

                                <?php $__errorArgs = ['pf_loan_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('note') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Note</label>

                            <div class="col-sm-10">
                                <input type="text" class="form-control" name="note" placeholder="Enter Note" value="<?php echo e(old('note')); ?>">

                                <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <!-- /.box-body -->

                    <div class="box-footer">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <!-- bootstrap datepicker -->
    <script src="<?php echo e(asset('themes/backend/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>
    <!-- Select2 -->
    <script src="<?php echo e(asset('themes/backend/bower_components/select2/dist/js/select2.full.min.js')); ?>"></script>

    <script>
        $(function () {
            //Date picker
            $('#start, #end').datepicker({
                autoclose: true,
                format: 'yyyy-mm-dd'
            });
        });
        //Initialize Select2 Elements
        $('.select2').select2()

        var APP_URL = '<?php echo url()->full(); ?>';
        function getprint(print) {

            $('body').html($('#'+print).html());
            window.print();
            window.location.replace(APP_URL)
        }
    </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\logic_new\resources\views/payroll/create_pf_loan/index.blade.php ENDPATH**/ ?>