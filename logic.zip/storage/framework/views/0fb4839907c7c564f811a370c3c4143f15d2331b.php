<?php $__env->startSection('content'); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">Candidate Evalution Information</h3>
            </div>

            <table class="table table-bordered">
                <thead>
                <tr>
                    <th style="font-size: 20px;" class="text-center" width="100%" scope="col">ACADEMIC & TRAINING INFORMATION</th>

                </tr>
                </thead>
            </table>
            <u><h4 class="text-center">Academic Information</h4></u>

            <form class="form-horizontal" method="POST" enctype="multipart/form-data" action="<?php echo e(route('academic_and_training.edit',['candidate' => $candidate->id])); ?>">
                <?php echo csrf_field(); ?>

                <div class="box-body">

                    <div class="form-group <?php echo e($errors->has('title') ? 'has-error' :''); ?>">
                        <label class="col-md-2 control-label">Title </label>

                        <div class="col-md-4">
                            <input type="text" class="form-control" placeholder="Enter Title"
                                   name="title" value="<?php echo e(empty(old('title')) ? ($errors->has('title') ? '' : $academicTraining->title) : old('title')); ?>">

                            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="help-block"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class=" <?php echo e($errors->has('institute') ? 'has-error' :''); ?>">
                            <label class="col-md-2 control-label">Institute</label>

                            <div class="col-md-4">
                                <input type="text" class="form-control" placeholder="Enter Institute"
                                       name="institute" value="<?php echo e(empty(old('institute')) ? ($errors->has('institute') ? '' : $academicTraining->institute) : old('institute')); ?>">

                                <?php $__errorArgs = ['institute'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <div class="form-group <?php echo e($errors->has('department') ? 'has-error' :''); ?>">
                        <label class="col-md-2 control-label">Department </label>

                        <div class="col-md-4">
                            <input type="text" class="form-control" placeholder="Enter Department"
                                   name="department" value="<?php echo e(empty(old('department')) ? ($errors->has('department') ? '' : $academicTraining->department) : old('department')); ?>">

                            <?php $__errorArgs = ['department'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="help-block"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class=" <?php echo e($errors->has('passing_year') ? 'has-error' :''); ?>">
                            <label class="col-md-2 control-label">Passing Year</label>

                            <div class="col-md-4">
                                <input type="text" class="form-control" placeholder="Enter Passing Year"
                                       name="passing_year" value="<?php echo e(empty(old('passing_year')) ? ($errors->has('passing_year') ? '' : $academicTraining->passing_year) : old('passing_year')); ?>">

                                <?php $__errorArgs = ['passing_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <div class="form-group <?php echo e($errors->has('result') ? 'has-error' :''); ?>">
                        <label class="col-md-2 control-label">Result </label>

                        <div class="col-md-4">
                            <input type="text" class="form-control" placeholder="Enter Result"
                                   name="result" value="<?php echo e(empty(old('result')) ? ($errors->has('result') ? '' : $academicTraining->result) : old('result')); ?>">

                            <?php $__errorArgs = ['result'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="help-block"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class=" <?php echo e($errors->has('out_off_result') ? 'has-error' :''); ?>">
                            <label class="col-md-2 control-label">Out Off Result </label>

                            <div class="col-md-4">
                                <input type="text" class="form-control" placeholder="Enter Out Off Result"
                                       name="out_off_result" value="<?php echo e(empty(old('out_off_result')) ? ($errors->has('out_off_result') ? '' : $academicTraining->out_off_result) : old('out_off_result')); ?>">

                                <?php $__errorArgs = ['out_off_result'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <div class="form-group <?php echo e($errors->has('duration') ? 'has-error' :''); ?>">
                        <label class="col-sm-2 control-label">Duration</label>

                        <div class="col-md-4">
                            <input type="text" class="form-control" placeholder="Enter Duration"
                                   name="duration" value="<?php echo e(empty(old('duration')) ? ($errors->has('duration') ? '' : $academicTraining->duration) : old('duration')); ?>">

                            <?php $__errorArgs = ['duration'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="help-block"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class=" <?php echo e($errors->has('academic_certificate') ? 'has-error' :''); ?>">
                            <label class="col-md-2 control-label">Academic Certificate Image </label>

                            <div class="col-sm-4">
                                <input type="file" class="form-control" name="academic_certificate">

                                <?php $__errorArgs = ['academic_certificate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                </div>











































                <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>

            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <!-- CK Editor -->
    <script src="<?php echo e(asset('themes/backend/bower_components/ckeditor/ckeditor.js')); ?>"></script>

    
    
    
    
    
    
    
    

    <script>

        var APP_URL = '<?php echo url()->full(); ?>';
        function getprint(prinarea_profile) {

            $('body').html($('#'+prinarea_profile).html());
            window.print();
            window.location.replace(APP_URL)
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\logic\resources\views/hr/academic_training/edit.blade.php ENDPATH**/ ?>