<?php $__env->startSection('style'); ?>
    <!-- bootstrap datepicker -->
    <link rel="stylesheet" href="<?php echo e(asset('themes/backend/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    Employee Edit
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Employee Information</h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <form class="form-horizontal" method="POST" enctype="multipart/form-data" action="<?php echo e(route('employee.edit', ['employee' => $employee->id])); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="box-body">
                        <div class="form-group <?php echo e($errors->has('name') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Name *</label>

                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="Enter Name"
                                       name="name" value="<?php echo e(empty(old('name')) ? ($errors->has('name') ? '' : $employee->name) : old('name')); ?>">

                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('employee_id') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Employee ID *</label>

                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="Enter Employee ID"
                                       name="employee_id" value="<?php echo e($employee->employee_id); ?>" readonly>

                                <?php $__errorArgs = ['employee_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('date_of_birth') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Date of Birth </label>

                            <div class="col-sm-10">
                                <div class="input-group date">
                                    <div class="input-group-addon">
                                        <i class="fa fa-calendar"></i>
                                    </div>
                                    <input type="text" class="form-control pull-right" id="dob" name="date_of_birth"
                                           value="<?php echo e(empty(old('date_of_birth')) ? ($errors->has('date_of_birth') ? '' : $employee->dob) : old('date_of_birth')); ?>" autocomplete="off">
                                </div>
                                <!-- /.input group -->

                                <?php $__errorArgs = ['date_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('interview_date') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Interview Date </label>

                            <div class="col-sm-10">
                                <div class="input-group date">
                                    <div class="input-group-addon">
                                        <i class="fa fa-calendar"></i>
                                    </div>
                                    <input type="text" class="form-control pull-right date-picker" name="interview_date"
                                           value="<?php echo e(empty(old('interview_date')) ? ($errors->has('interview_date') ? '' : $employee->interview_date) : old('interview_date')); ?>" autocomplete="off">
                                </div>
                                <!-- /.input group -->

                                <?php $__errorArgs = ['interview_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('expected_joining_date') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Expected Joining Date </label>

                            <div class="col-sm-10">
                                <div class="input-group date">
                                    <div class="input-group-addon">
                                        <i class="fa fa-calendar"></i>
                                    </div>
                                    <input type="text" class="form-control pull-right date-picker" name="expected_joining_date"
                                           value="<?php echo e(empty(old('expected_joining_date')) ? ($errors->has('expected_joining_date') ? '' : $employee->expected_joining_date) : old('expected_joining_date')); ?>" autocomplete="off">

                                </div>
                                <!-- /.input group -->

                                <?php $__errorArgs = ['expected_joining_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('joining_date') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Joining Date </label>

                            <div class="col-sm-10">
                                <div class="input-group date">
                                    <div class="input-group-addon">
                                        <i class="fa fa-calendar"></i>
                                    </div>
                                    <input type="text" class="form-control pull-right date-picker" name="joining_date"
                                           value="<?php echo e(empty(old('joining_date')) ? ($errors->has('joining_date') ? '' : $employee->joining_date) : old('joining_date')); ?>" autocomplete="off">
                                </div>
                                <!-- /.input group -->

                                <?php $__errorArgs = ['joining_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('confirmation_date') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Confirmation Date </label>

                            <div class="col-sm-10">
                                <div class="input-group date">
                                    <div class="input-group-addon">
                                        <i class="fa fa-calendar"></i>
                                    </div>
                                    <input type="text" class="form-control pull-right date-picker" name="confirmation_date"
                                           value="<?php echo e(empty(old('confirmation_date')) ? ($errors->has('confirmation_date') ? '' : $employee->confirmation_date) : old('confirmation_date')); ?>" autocomplete="off">
                                </div>
                                <!-- /.input group -->

                                <?php $__errorArgs = ['confirmation_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group <?php echo e($errors->has('education_qualification') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Education Qualification </label>

                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="Enter Education Qualification"
                                       name="education_qualification" value="<?php echo e(empty(old('education_qualification')) ? ($errors->has('education_qualification') ? '' : $employee->education_qualification) : old('education_qualification')); ?>">

                                <?php $__errorArgs = ['education_qualification'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>


                        <div class="form-group <?php echo e($errors->has('department') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Department *</label>

                            <div class="col-sm-10">
                                <select class="form-control" name="department" id="department">
                                    <option value="">Select Department</option>

                                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($department->id); ?>" <?php echo e(empty(old('department')) ? ($errors->has('department') ? '' : ($employee->department_id == $department->id ? 'selected' : '')) :
                                            (old('department') == $department->id ? 'selected' : '')); ?>><?php echo e($department->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                                <?php $__errorArgs = ['department'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('designation') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Designation *</label>

                            <div class="col-sm-10">
                                <select class="form-control" name="designation" id="designation">
                                    <option value="">Select Designation</option>
                                </select>

                                <?php $__errorArgs = ['designation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('employee_type') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Employee Type *</label>

                            <div class="col-sm-10">
                                <select class="form-control" name="employee_type" >
                                    <option value="">Select Employee Type</option>
                                    <option value="1" <?php echo e(empty(old('employee_type')) ? ($errors->has('employee_type') ? '' : ($employee->employee_type == '1' ? 'selected' : '')) :
                                            (old('employee_type') == '1' ? 'selected' : '')); ?>>Permanent</option>
                                    <option value="2" <?php echo e(empty(old('employee_type')) ? ($errors->has('employee_type') ? '' : ($employee->employee_type == '2' ? 'selected' : '')) :
                                            (old('employee_type') == '2' ? 'selected' : '')); ?>>Temporary</option>
                                </select>

                                <?php $__errorArgs = ['employee_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('gender') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Gender *</label>

                            <div class="col-sm-10">
                                <select class="form-control" name="gender" >
                                    <option value="">Select Gender</option>
                                    <option value="1" <?php echo e(empty(old('gender')) ? ($errors->has('gender') ? '' : ($employee->gender == '1' ? 'selected' : '')) :
                                            (old('gender') == '1' ? 'selected' : '')); ?>>Male</option>
                                    <option value="2" <?php echo e(empty(old('gender')) ? ($errors->has('gender') ? '' : ($employee->gender == '2' ? 'selected' : '')) :
                                            (old('gender') == '2' ? 'selected' : '')); ?>>Female</option>
                                </select>

                                <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('marital_status') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Marital Status *</label>

                            <div class="col-sm-10">
                                <select class="form-control" name="marital_status" >
                                    <option value="">Select Marital Status</option>
                                    <option value="1" <?php echo e(empty(old('marital_status')) ? ($errors->has('marital_status') ? '' : ($employee->marital_status == '1' ? 'selected' : '')) :
                                            (old('marital_status') == '1' ? 'selected' : '')); ?>>Single</option>
                                    <option value="2" <?php echo e(empty(old('marital_status')) ? ($errors->has('marital_status') ? '' : ($employee->marital_status == '2' ? 'selected' : '')) :
                                            (old('marital_status') == '2' ? 'selected' : '')); ?>>Married</option>
                                </select>

                                <?php $__errorArgs = ['marital_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('mobile_no') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Mobile No. </label>

                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="Enter Mobile No."
                                       name="mobile_no" value="<?php echo e(empty(old('mobile_no')) ? ($errors->has('mobile_no') ? '' : $employee->mobile_no) : old('mobile_no')); ?>">

                                <?php $__errorArgs = ['mobile_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('father_name') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Father Name </label>

                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="Enter Father Name"
                                       name="father_name" value="<?php echo e(empty(old('father_name')) ? ($errors->has('father_name') ? '' : $employee->father_name) : old('father_name')); ?>">

                                <?php $__errorArgs = ['father_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('mother_name') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Mother Name </label>

                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="Enter Mother Name"
                                       name="mother_name" value="<?php echo e(empty(old('mother_name')) ? ($errors->has('mother_name') ? '' : $employee->mother_name) : old('mother_name')); ?>">

                                <?php $__errorArgs = ['mother_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('emergency_contact') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Emergency Contact *</label>

                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="Enter Emergency Contact"
                                       name="emergency_contact" value="<?php echo e(empty(old('emergency_contact')) ? ($errors->has('emergency_contact') ? '' : $employee->emergency_contact) : old('emergency_contact')); ?>">

                                <?php $__errorArgs = ['emergency_contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('signature') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Signature</label>

                            <div class="col-sm-10">
                                <input type="file" class="form-control" name="signature">

                                <?php $__errorArgs = ['signature'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('photo') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Photo</label>

                            <div class="col-sm-10">
                                <input type="file" class="form-control" name="photo">

                                <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('present_address') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Present Address *</label>

                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="Enter Present Address"
                                       name="present_address" value="<?php echo e(empty(old('present_address')) ? ($errors->has('present_address') ? '' : $employee->present_address) : old('present_address')); ?>">

                                <?php $__errorArgs = ['present_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('permanent_address') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Permanent Address *</label>

                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="Enter Permanent Address"
                                       name="permanent_address" value="<?php echo e(empty(old('permanent_address')) ? ($errors->has('permanent_address') ? '' : $employee->permanent_address) : old('permanent_address')); ?>">

                                <?php $__errorArgs = ['permanent_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('email') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Email </label>

                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="Enter Email"
                                       name="email" value="<?php echo e(empty(old('email')) ? ($errors->has('email') ? '' : $employee->email) : old('email')); ?>">

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('religion') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Religion *</label>

                            <div class="col-sm-10">
                                <select class="form-control" name="religion" >
                                    <option value="">Select Religion</option>
                                    <option value="1" <?php echo e(empty(old('religion')) ? ($errors->has('religion') ? '' : ($employee->religion == '1' ? 'selected' : '')) :
                                            (old('religion') == '1' ? 'selected' : '')); ?>>Muslim</option>
                                    <option value="2" <?php echo e(empty(old('religion')) ? ($errors->has('religion') ? '' : ($employee->religion == '2' ? 'selected' : '')) :
                                            (old('religion') == '2' ? 'selected' : '')); ?>>Hindu</option>
                                    <option value="3" <?php echo e(empty(old('religion')) ? ($errors->has('religion') ? '' : ($employee->religion == '3' ? 'selected' : '')) :
                                            (old('religion') == '3' ? 'selected' : '')); ?>>Christian</option>
                                    <option value="4" <?php echo e(empty(old('religion')) ? ($errors->has('religion') ? '' : ($employee->religion == '4' ? 'selected' : '')) :
                                            (old('religion') == '4' ? 'selected' : '')); ?>>Other</option>
                                </select>

                                <?php $__errorArgs = ['religion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('cv') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">CV</label>

                            <div class="col-sm-10">
                                <input type="file" class="form-control" name="cv">

                                <?php $__errorArgs = ['cv'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('expected_salary') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Expected Salary </label>

                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="Enter Expected Salary"
                                       name="expected_salary" value="<?php echo e(empty(old('expected_salary')) ? ($errors->has('expected_salary') ? '' : $employee->expected_salary) : old('expected_salary')); ?>">

                                <?php $__errorArgs = ['expected_salary'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('salary_offered') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Salary_Offered </label>

                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="Enter Offered Salary"
                                       name="salary_offered" value="<?php echo e(empty(old('salary_offered')) ? ($errors->has('salary_offered') ? '' : $employee->salary_offered) : old('salary_offered')); ?>">

                                <?php $__errorArgs = ['salary_offered'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('other_benefits') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Other Benefits </label>

                            <div class="col-md-10">
                                <textarea name="other_benefits" id="other_benefits" placeholder="Text Other Benefits" class="form-control"><?php echo e($employee->other_benefits); ?></textarea>

                                <?php $__errorArgs = ['other_benefits'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>


                        <div class="form-group <?php echo e($errors->has('any_condition') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Any Condition </label>

                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="Enter Any Condition"
                                       name="any_condition" value="<?php echo e(empty(old('any_condition')) ? ($errors->has('any_condition') ? '' : $employee->any_condition) : old('any_condition')); ?>">

                                <?php $__errorArgs = ['any_condition'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>


                        <div class="form-group <?php echo e($errors->has('required_company_unit') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Required Company Unit </label>

                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="Enter Offered Salary"
                                       name="required_company_unit" value="<?php echo e(empty(old('required_company_unit')) ? ($errors->has('required_company_unit') ? '' : $employee->required_company_unit) : old('required_company_unit')); ?>">

                                <?php $__errorArgs = ['required_company_unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('job_description') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Job_Description </label>

                            <div class="col-md-10">
                                <textarea name="job_description" id="job_description" placeholder="Job Description" class="form-control"><?php echo e(empty(old('job_description')) ? ($errors->has('job_description') ? '' : $employee->job_description) : old('job_description')); ?></textarea>
                                <?php $__errorArgs = ['job_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('dress_up') ? 'has-error' :''); ?>">

                            <div class="row">
                                <div class="col-md-12">
                                    <div style="text-align: center;margin-bottom: 10px;" class="section">
                                        <strong><u>APPEARANCE</u></strong>
                                    </div>
                                </div>
                            </div>

                            <label class="col-sm-2 control-label">Dress Up</label>
                            <div class="col-sm-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <div style="margin-top: 7px;" class="input-group-text">
                                            <input type="radio" value="1" <?php echo e(empty(old('dress_up')) ? ($errors->has('dress_up') ? '' : ($employee->dress_up == '1' ? 'checked' : '')) :
                                            (old('dress_up') == '1' ? 'checked' : '')); ?> name="dress_up">
                                            <span style="margin-left: 2px;">1</span>
                                            <input style="margin-left: 35px;" type="radio" value="2" <?php echo e(empty(old('dress_up')) ? ($errors->has('dress_up') ? '' : ($employee->dress_up == '2' ? 'checked' : '')) :
                                            (old('dress_up') == '2' ? 'checked' : '')); ?> name="dress_up">
                                            <span style="margin-left: 2px;">2</span>
                                            <input style="margin-left: 35px;" type="radio" value="3" <?php echo e(empty(old('dress_up')) ? ($errors->has('dress_up') ? '' : ($employee->dress_up == '3' ? 'checked' : '')) :
                                            (old('dress_up') == '3' ? 'checked' : '')); ?> name="dress_up">
                                            <span  style="margin-left: 2px;">3</span>
                                            <input style="margin-left: 35px;" type="radio" value="4" <?php echo e(empty(old('dress_up')) ? ($errors->has('dress_up') ? '' : ($employee->dress_up == '4' ? 'checked' : '')) :
                                            (old('dress_up') == '4' ? 'checked' : '')); ?> name="dress_up">
                                            <span style="margin-left: 2px;">4</span>
                                            <input style="margin-left: 35px;" type="radio" value="5" <?php echo e(empty(old('dress_up')) ? ($errors->has('dress_up') ? '' : ($employee->dress_up == '5' ? 'checked' : '')) :
                                            (old('dress_up') == '5' ? 'checked' : '')); ?> name="dress_up">
                                            <span style="margin-left: 2px;">5</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <label class="col-sm-2 control-label">Grooming Up</label>

                            <div class="col-sm-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <div style="margin-top: 7px;" class="input-group-text">
                                            <input type="radio" value="1" <?php echo e(empty(old('grooming_up')) ? ($errors->has('grooming_up') ? '' : ($employee->grooming_up == '1' ? 'checked' : '')) :
                                            (old('grooming_up') == '1' ? 'checked' : '')); ?> name="grooming_up">
                                            <span style="margin-left: 2px;">1</span>
                                            <input style="margin-left: 35px;" type="radio" value="2" <?php echo e(empty(old('grooming_up')) ? ($errors->has('grooming_up') ? '' : ($employee->grooming_up == '2' ? 'checked' : '')) :
                                            (old('grooming_up') == '2' ? 'checked' : '')); ?> name="grooming_up">
                                            <span style="margin-left: 2px;">2</span>
                                            <input style="margin-left: 35px;" type="radio" value="3" <?php echo e(empty(old('grooming_up')) ? ($errors->has('grooming_up') ? '' : ($employee->grooming_up == '3' ? 'checked' : '')) :
                                            (old('grooming_up') == '3' ? 'checked' : '')); ?> name="grooming_up">
                                            <span  style="margin-left: 2px;">3</span>
                                            <input style="margin-left: 35px;" type="radio" value="4" <?php echo e(empty(old('grooming_up')) ? ($errors->has('grooming_up') ? '' : ($employee->grooming_up == '4' ? 'checked' : '')) :
                                            (old('grooming_up') == '4' ? 'checked' : '')); ?> name="grooming_up">
                                            <span style="margin-left: 2px;">4</span>
                                            <input style="margin-left: 35px;" type="radio" value="5" <?php echo e(empty(old('grooming_up')) ? ($errors->has('grooming_up') ? '' : ($employee->grooming_up == '5' ? 'checked' : '')) :
                                            (old('grooming_up') == '5' ? 'checked' : '')); ?> name="grooming_up">
                                            <span style="margin-left: 2px;">5</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('body_language') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Body Language</label>
                            <div class="col-sm-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <div style="margin-top: 7px;" class="input-group-text">
                                            <input type="radio" value="1" <?php echo e(empty(old('body_language')) ? ($errors->has('body_language') ? '' : ($employee->body_language == '1' ? 'checked' : '')) :
                                            (old('body_language') == '1' ? 'checked' : '')); ?> name="body_language">
                                            <span style="margin-left: 2px;">1</span>
                                            <input style="margin-left: 35px;" type="radio" value="2" <?php echo e(empty(old('body_language')) ? ($errors->has('body_language') ? '' : ($employee->body_language == '2' ? 'checked' : '')) :
                                            (old('body_language') == '2' ? 'checked' : '')); ?> name="body_language">
                                            <span style="margin-left: 2px;">2</span>
                                            <input style="margin-left: 35px;" type="radio" value="3" <?php echo e(empty(old('body_language')) ? ($errors->has('body_language') ? '' : ($employee->body_language == '3' ? 'checked' : '')) :
                                            (old('body_language') == '3' ? 'checked' : '')); ?> name="body_language">
                                            <span  style="margin-left: 2px;">3</span>
                                            <input style="margin-left: 35px;" type="radio" value="4" <?php echo e(empty(old('body_language')) ? ($errors->has('body_language') ? '' : ($employee->body_language == '4' ? 'checked' : '')) :
                                            (old('body_language') == '4' ? 'checked' : '')); ?> name="body_language">
                                            <span style="margin-left: 2px;">4</span>
                                            <input style="margin-left: 35px;" type="radio" value="5" <?php echo e(empty(old('body_language')) ? ($errors->has('body_language') ? '' : ($employee->body_language == '5' ? 'checked' : '')) :
                                            (old('body_language') == '5' ? 'checked' : '')); ?> name="body_language">
                                            <span style="margin-left: 2px;">5</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <label class="col-sm-2 control-label">Attitude</label>

                            <div class="col-sm-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <div style="margin-top: 7px;" class="input-group-text">
                                            <input type="radio" value="1" <?php echo e(empty(old('attitude')) ? ($errors->has('attitude') ? '' : ($employee->attitude == '1' ? 'checked' : '')) :
                                            (old('attitude') == '1' ? 'checked' : '')); ?> name="attitude">
                                            <span style="margin-left: 2px;">1</span>
                                            <input style="margin-left: 35px;" type="radio" value="2" <?php echo e(empty(old('attitude')) ? ($errors->has('attitude') ? '' : ($employee->attitude == '2' ? 'checked' : '')) :
                                            (old('attitude') == '2' ? 'checked' : '')); ?> name="attitude">
                                            <span style="margin-left: 2px;">2</span>
                                            <input style="margin-left: 35px;" type="radio" value="3" <?php echo e(empty(old('attitude')) ? ($errors->has('attitude') ? '' : ($employee->attitude == '3' ? 'checked' : '')) :
                                            (old('attitude') == '3' ? 'checked' : '')); ?> name="attitude">
                                            <span  style="margin-left: 2px;">3</span>
                                            <input style="margin-left: 35px;" type="radio" value="4" <?php echo e(empty(old('attitude')) ? ($errors->has('attitude') ? '' : ($employee->attitude == '4' ? 'checked' : '')) :
                                            (old('attitude') == '4' ? 'checked' : '')); ?> name="attitude">
                                            <span style="margin-left: 2px;">4</span>
                                            <input style="margin-left: 35px;" type="radio" value="5" <?php echo e(empty(old('attitude')) ? ($errors->has('attitude') ? '' : ($employee->attitude == '5' ? 'checked' : '')) :
                                            (old('attitude') == '5' ? 'checked' : '')); ?> name="attitude">
                                            <span style="margin-left: 2px;">5</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('personality') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Personality</label>
                            <div class="col-sm-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <div style="margin-top: 7px;" class="input-group-text">
                                            <input type="radio" value="1" <?php echo e(empty(old('personality')) ? ($errors->has('personality') ? '' : ($employee->personality == '1' ? 'checked' : '')) :
                                            (old('personality') == '1' ? 'checked' : '')); ?> name="personality">
                                            <span style="margin-left: 2px;">1</span>
                                            <input style="margin-left: 35px;" type="radio" value="2" <?php echo e(empty(old('personality')) ? ($errors->has('personality') ? '' : ($employee->personality == '2' ? 'checked' : '')) :
                                            (old('personality') == '2' ? 'checked' : '')); ?> name="personality">
                                            <span style="margin-left: 2px;">2</span>
                                            <input style="margin-left: 35px;" type="radio" value="3" <?php echo e(empty(old('personality')) ? ($errors->has('personality') ? '' : ($employee->personality == '3' ? 'checked' : '')) :
                                            (old('personality') == '3' ? 'checked' : '')); ?> name="personality">
                                            <span  style="margin-left: 2px;">3</span>
                                            <input style="margin-left: 35px;" type="radio" value="4" <?php echo e(empty(old('personality')) ? ($errors->has('personality') ? '' : ($employee->personality == '4' ? 'checked' : '')) :
                                            (old('personality') == '4' ? 'checked' : '')); ?> name="personality">
                                            <span style="margin-left: 2px;">4</span>
                                            <input style="margin-left: 35px;" type="radio" value="5" <?php echo e(empty(old('personality')) ? ($errors->has('personality') ? '' : ($employee->personality == '5' ? 'checked' : '')) :
                                            (old('personality') == '5' ? 'checked' : '')); ?> name="personality">
                                            <span style="margin-left: 2px;">5</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <label class="col-sm-2 control-label">CV Status</label>

                            <div class="col-sm-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <div style="margin-top: 7px;" class="input-group-text">
                                            <input type="radio" value="1" <?php echo e(empty(old('cv_status')) ? ($errors->has('cv_status') ? '' : ($employee->cv_status == '1' ? 'checked' : '')) :
                                            (old('cv_status') == '5' ? 'checked' : '')); ?> name="cv_status">
                                            <span style="margin-left: 2px;">1</span>
                                            <input style="margin-left: 35px;" type="radio" value="2" <?php echo e(empty(old('cv_status')) ? ($errors->has('cv_status') ? '' : ($employee->cv_status == '2' ? 'checked' : '')) :
                                            (old('cv_status') == '5' ? 'checked' : '')); ?> name="cv_status">
                                            <span style="margin-left: 2px;">2</span>
                                            <input style="margin-left: 35px;" type="radio" value="3" <?php echo e(empty(old('cv_status')) ? ($errors->has('cv_status') ? '' : ($employee->cv_status == '3' ? 'checked' : '')) :
                                            (old('cv_status') == '5' ? 'checked' : '')); ?> name="cv_status">
                                            <span  style="margin-left: 2px;">3</span>
                                            <input style="margin-left: 35px;" type="radio" value="4" <?php echo e(empty(old('cv_status')) ? ($errors->has('cv_status') ? '' : ($employee->cv_status == '4' ? 'checked' : '')) :
                                            (old('cv_status') == '5' ? 'checked' : '')); ?> name="cv_status">
                                            <span style="margin-left: 2px;">4</span>
                                            <input style="margin-left: 35px;" type="radio"value="5" <?php echo e(empty(old('cv_status')) ? ($errors->has('cv_status') ? '' : ($employee->cv_status == '5' ? 'checked' : '')) :
                                            (old('cv_status') == '5' ? 'checked' : '')); ?> name="cv_status">
                                            <span style="margin-left: 2px;">5</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div style="text-align: center;margin-bottom: 10px;margin-top: 10px;" class="section">
                                    <strong><u>QUALIFICATION</u></strong>
                                </div>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('educational_qualification') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Educational Qualification</label>
                            <div class="col-sm-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <div style="margin-top: 7px;" class="input-group-text">
                                            <input type="radio" value="1" <?php echo e(empty(old('educational_qualification')) ? ($errors->has('educational_qualification') ? '' : ($employee->educational_qualification == '1' ? 'checked' : '')) :
                                            (old('educational_qualification') == '1' ? 'checked' : '')); ?> name="educational_qualification">
                                            <span style="margin-left: 2px;">1</span>
                                            <input style="margin-left: 35px;" type="radio" value="2" <?php echo e(empty(old('educational_qualification')) ? ($errors->has('educational_qualification') ? '' : ($employee->educational_qualification == '2' ? 'checked' : '')) :
                                            (old('educational_qualification') == '2' ? 'checked' : '')); ?> name="educational_qualification">
                                            <span style="margin-left: 2px;">2</span>
                                            <input style="margin-left: 35px;" type="radio" value="3" <?php echo e(empty(old('educational_qualification')) ? ($errors->has('educational_qualification') ? '' : ($employee->educational_qualification == '3' ? 'checked' : '')) :
                                            (old('educational_qualification') == '3' ? 'checked' : '')); ?> name="educational_qualification">
                                            <span  style="margin-left: 2px;">3</span>
                                            <input style="margin-left: 35px;" type="radio" value="4" <?php echo e(empty(old('educational_qualification')) ? ($errors->has('educational_qualification') ? '' : ($employee->educational_qualification == '4' ? 'checked' : '')) :
                                            (old('educational_qualification') == '4' ? 'checked' : '')); ?> name="educational_qualification">
                                            <span style="margin-left: 2px;">4</span>
                                            <input style="margin-left: 35px;" type="radio" value="5" <?php echo e(empty(old('educational_qualification')) ? ($errors->has('educational_qualification') ? '' : ($employee->educational_qualification == '5' ? 'checked' : '')) :
                                            (old('educational_qualification') == '5' ? 'checked' : '')); ?> name="educational_qualification">
                                            <span style="margin-left: 2px;">5</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <label class="col-sm-2 control-label">Professional Qualification</label>

                            <div class="col-sm-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <div style="margin-top: 7px;" class="input-group-text">
                                            <input type="radio" value="1" <?php echo e(empty(old('professional_qualification')) ? ($errors->has('professional_qualification') ? '' : ($employee->professional_qualification == '1' ? 'checked' : '')) :
                                            (old('professional_qualification') == '1' ? 'checked' : '')); ?> name="professional_qualification">
                                            <span style="margin-left: 2px;">1</span>
                                            <input style="margin-left: 35px;" type="radio" value="2" <?php echo e(empty(old('professional_qualification')) ? ($errors->has('professional_qualification') ? '' : ($employee->professional_qualification == '2' ? 'checked' : '')) :
                                            (old('professional_qualification') == '2' ? 'checked' : '')); ?> name="professional_qualification">
                                            <span style="margin-left: 2px;">2</span>
                                            <input style="margin-left: 35px;" type="radio" value="3" <?php echo e(empty(old('professional_qualification')) ? ($errors->has('professional_qualification') ? '' : ($employee->professional_qualification == '3' ? 'checked' : '')) :
                                            (old('professional_qualification') == '3' ? 'checked' : '')); ?> name="professional_qualification">
                                            <span  style="margin-left: 2px;">3</span>
                                            <input style="margin-left: 35px;" type="radio" value="4" <?php echo e(empty(old('professional_qualification')) ? ($errors->has('professional_qualification') ? '' : ($employee->professional_qualification == '4' ? 'checked' : '')) :
                                            (old('professional_qualification') == '4' ? 'checked' : '')); ?> name="professional_qualification">
                                            <span style="margin-left: 2px;">4</span>
                                            <input style="margin-left: 35px;" type="radio" value="5" <?php echo e(empty(old('professional_qualification')) ? ($errors->has('professional_qualification') ? '' : ($employee->professional_qualification == '5' ? 'checked' : '')) :
                                            (old('professional_qualification') == '5' ? 'checked' : '')); ?> name="professional_qualification">
                                            <span style="margin-left: 2px;">5</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group <?php echo e($errors->has('training_and_others') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Training and Others
                            </label>
                            <div class="col-sm-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <div style="margin-top: 7px;" class="input-group-text">
                                            <input type="radio" value="1" <?php echo e(empty(old('training_and_others')) ? ($errors->has('training_and_others') ? '' : ($employee->training_and_others == '1' ? 'checked' : '')) :
                                            (old('training_and_others') == '1' ? 'checked' : '')); ?> name="training_and_others">
                                            <span style="margin-left: 2px;">1</span>
                                            <input style="margin-left: 35px;" type="radio" value="2" <?php echo e(empty(old('training_and_others')) ? ($errors->has('training_and_others') ? '' : ($employee->training_and_others == '2' ? 'checked' : '')) :
                                            (old('training_and_others') == '2' ? 'checked' : '')); ?> name="training_and_others">
                                            <span style="margin-left: 2px;">2</span>
                                            <input style="margin-left: 35px;" type="radio" value="3" <?php echo e(empty(old('training_and_others')) ? ($errors->has('training_and_others') ? '' : ($employee->training_and_others == '3' ? 'checked' : '')) :
                                            (old('training_and_others') == '3' ? 'checked' : '')); ?> name="training_and_others">
                                            <span  style="margin-left: 2px;">3</span>
                                            <input style="margin-left: 35px;" type="radio" value="4" <?php echo e(empty(old('training_and_others')) ? ($errors->has('training_and_others') ? '' : ($employee->training_and_others == '4' ? 'checked' : '')) :
                                            (old('training_and_others') == '4' ? 'checked' : '')); ?> name="training_and_others">
                                            <span style="margin-left: 2px;">4</span>
                                            <input style="margin-left: 35px;" type="radio" value="5" <?php echo e(empty(old('training_and_others')) ? ($errors->has('training_and_others') ? '' : ($employee->training_and_others == '5' ? 'checked' : '')) :
                                            (old('training_and_others') == '5' ? 'checked' : '')); ?> name="training_and_others">
                                            <span style="margin-left: 2px;">5</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <label class="col-sm-2 control-label">Award Recogntion</label>

                            <div class="col-sm-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <div style="margin-top: 7px;" class="input-group-text">
                                            <input type="radio" value="1" <?php echo e(empty(old('award_recogntion')) ? ($errors->has('award_recogntion') ? '' : ($employee->award_recogntion == '1' ? 'checked' : '')) :
                                            (old('award_recogntion') == '1' ? 'checked' : '')); ?> name="award_recogntion">
                                            <span style="margin-left: 2px;">1</span>
                                            <input style="margin-left: 35px;" type="radio" value="2" <?php echo e(empty(old('award_recogntion')) ? ($errors->has('award_recogntion') ? '' : ($employee->award_recogntion == '2' ? 'checked' : '')) :
                                            (old('award_recogntion') == '2' ? 'checked' : '')); ?> name="award_recogntion">
                                            <span style="margin-left: 2px;">2</span>
                                            <input style="margin-left: 35px;" type="radio" value="3" <?php echo e(empty(old('award_recogntion')) ? ($errors->has('award_recogntion') ? '' : ($employee->award_recogntion == '3' ? 'checked' : '')) :
                                            (old('award_recogntion') == '3' ? 'checked' : '')); ?> name="award_recogntion">
                                            <span  style="margin-left: 2px;">3</span>
                                            <input style="margin-left: 35px;" type="radio" value="4" <?php echo e(empty(old('award_recogntion')) ? ($errors->has('award_recogntion') ? '' : ($employee->award_recogntion == '4' ? 'checked' : '')) :
                                            (old('award_recogntion') == '4' ? 'checked' : '')); ?> name="award_recogntion">
                                            <span style="margin-left: 2px;">4</span>
                                            <input style="margin-left: 35px;" type="radio" value="5" <?php echo e(empty(old('award_recogntion')) ? ($errors->has('award_recogntion') ? '' : ($employee->award_recogntion == '5' ? 'checked' : '')) :
                                            (old('award_recogntion') == '5' ? 'checked' : '')); ?> name="award_recogntion">
                                            <span style="margin-left: 2px;">5</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div style="text-align: center;margin-bottom: 10px;margin-top: 10px;" class="section">
                                    <strong><u>EXPERIENCE</u></strong>
                                </div>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('relevent_experience') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Relevent Experience
                            </label>
                            <div class="col-sm-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <div style="margin-top: 7px;" class="input-group-text">
                                            <input type="radio" value="1" <?php echo e(empty(old('relevent_experience')) ? ($errors->has('relevent_experience') ? '' : ($employee->relevent_experience == '1' ? 'checked' : '')) :
                                            (old('relevent_experience') == '1' ? 'checked' : '')); ?> name="relevent_experience">
                                            <span style="margin-left: 2px;">1</span>
                                            <input style="margin-left: 35px;" type="radio" value="2" <?php echo e(empty(old('relevent_experience')) ? ($errors->has('relevent_experience') ? '' : ($employee->relevent_experience == '2' ? 'checked' : '')) :
                                            (old('relevent_experience') == '2' ? 'checked' : '')); ?> name="relevent_experience">
                                            <span style="margin-left: 2px;">2</span>
                                            <input style="margin-left: 35px;" type="radio" value="3" <?php echo e(empty(old('relevent_experience')) ? ($errors->has('relevent_experience') ? '' : ($employee->relevent_experience == '3' ? 'checked' : '')) :
                                            (old('relevent_experience') == '3' ? 'checked' : '')); ?> name="relevent_experience">
                                            <span  style="margin-left: 2px;">3</span>
                                            <input style="margin-left: 35px;" type="radio" value="4" <?php echo e(empty(old('relevent_experience')) ? ($errors->has('relevent_experience') ? '' : ($employee->relevent_experience == '4' ? 'checked' : '')) :
                                            (old('relevent_experience') == '4' ? 'checked' : '')); ?> name="relevent_experience">
                                            <span style="margin-left: 2px;">4</span>
                                            <input style="margin-left: 35px;" type="radio" value="5" <?php echo e(empty(old('relevent_experience')) ? ($errors->has('relevent_experience') ? '' : ($employee->relevent_experience == '5' ? 'checked' : '')) :
                                            (old('relevent_experience') == '5' ? 'checked' : '')); ?> name="relevent_experience">
                                            <span style="margin-left: 2px;">5</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <label class="col-sm-2 control-label">Professional Achievements</label>

                            <div class="col-sm-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <div style="margin-top: 7px;" class="input-group-text">
                                            <input type="radio" value="1" <?php echo e(empty(old('professional_achievements')) ? ($errors->has('professional_achievements') ? '' : ($employee->professional_achievements == '1' ? 'checked' : '')) :
                                            (old('professional_achievements') == '1' ? 'checked' : '')); ?> name="professional_achievements">
                                            <span style="margin-left: 2px;">1</span>
                                            <input style="margin-left: 35px;" type="radio" value="2" <?php echo e(empty(old('professional_achievements')) ? ($errors->has('professional_achievements') ? '' : ($employee->professional_achievements == '2' ? 'checked' : '')) :
                                            (old('professional_achievements') == '2' ? 'checked' : '')); ?> name="professional_achievements">
                                            <span style="margin-left: 2px;">2</span>
                                            <input style="margin-left: 35px;" type="radio" value="3" <?php echo e(empty(old('professional_achievements')) ? ($errors->has('professional_achievements') ? '' : ($employee->professional_achievements == '3' ? 'checked' : '')) :
                                            (old('professional_achievements') == '3' ? 'checked' : '')); ?> name="professional_achievements">
                                            <span  style="margin-left: 2px;">3</span>
                                            <input style="margin-left: 35px;" type="radio" value="4" <?php echo e(empty(old('professional_achievements')) ? ($errors->has('professional_achievements') ? '' : ($employee->professional_achievements == '4' ? 'checked' : '')) :
                                            (old('professional_achievements') == '4' ? 'checked' : '')); ?> name="professional_achievements">
                                            <span style="margin-left: 2px;">4</span>
                                            <input style="margin-left: 35px;" type="radio" value="5" <?php echo e(empty(old('professional_achievements')) ? ($errors->has('professional_achievements') ? '' : ($employee->professional_achievements == '5' ? 'checked' : '')) :
                                            (old('professional_achievements') == '5' ? 'checked' : '')); ?> name="professional_achievements">
                                            <span style="margin-left: 2px;">5</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group <?php echo e($errors->has('potentiality') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Potentiality</label>
                            <div class="col-sm-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <div style="margin-top: 7px;" class="input-group-text">
                                            <input type="radio" value="1" <?php echo e(empty(old('potentiality')) ? ($errors->has('potentiality') ? '' : ($employee->potentiality == '1' ? 'checked' : '')) :
                                            (old('potentiality') == '1' ? 'checked' : '')); ?> name="potentiality">
                                            <span style="margin-left: 2px;">1</span>
                                            <input style="margin-left: 35px;" type="radio" value="2" <?php echo e(empty(old('potentiality')) ? ($errors->has('potentiality') ? '' : ($employee->potentiality == '2' ? 'checked' : '')) :
                                            (old('potentiality') == '2' ? 'checked' : '')); ?> name="potentiality">
                                            <span style="margin-left: 2px;">2</span>
                                            <input style="margin-left: 35px;" type="radio" value="3" <?php echo e(empty(old('potentiality')) ? ($errors->has('potentiality') ? '' : ($employee->potentiality == '3' ? 'checked' : '')) :
                                            (old('potentiality') == '3' ? 'checked' : '')); ?> name="potentiality">
                                            <span  style="margin-left: 2px;">3</span>
                                            <input style="margin-left: 35px;" type="radio" value="4" <?php echo e(empty(old('potentiality')) ? ($errors->has('potentiality') ? '' : ($employee->potentiality == '4' ? 'checked' : '')) :
                                            (old('potentiality') == '4' ? 'checked' : '')); ?> name="potentiality">
                                            <span style="margin-left: 2px;">4</span>
                                            <input style="margin-left: 35px;" type="radio" value="5" <?php echo e(empty(old('potentiality')) ? ($errors->has('potentiality') ? '' : ($employee->potentiality == '5' ? 'checked' : '')) :
                                            (old('potentiality') == '5' ? 'checked' : '')); ?> name="potentiality">
                                            <span style="margin-left: 2px;">5</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <div style="text-align: center;margin-bottom: 10px;margin-top: 10px;" class="section">
                                        <strong><u>COMMUNICATION</u></strong>
                                    </div>
                                </div>
                            </div>

                            <label class="col-sm-2 control-label">Oral Communication</label>

                            <div class="col-sm-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <div style="margin-top: 7px;" class="input-group-text">
                                            <input type="radio" value="1" <?php echo e(empty(old('oral_communication')) ? ($errors->has('oral_communication') ? '' : ($employee->oral_communication == '1' ? 'checked' : '')) :
                                            (old('oral_communication') == '1' ? 'checked' : '')); ?> name="oral_communication">
                                            <span style="margin-left: 2px;">1</span>
                                            <input style="margin-left: 35px;" type="radio" value="2" <?php echo e(empty(old('oral_communication')) ? ($errors->has('oral_communication') ? '' : ($employee->oral_communication == '2' ? 'checked' : '')) :
                                            (old('oral_communication') == '2' ? 'checked' : '')); ?> name="oral_communication">
                                            <span style="margin-left: 2px;">2</span>
                                            <input style="margin-left: 35px;" type="radio" value="3" <?php echo e(empty(old('oral_communication')) ? ($errors->has('oral_communication') ? '' : ($employee->oral_communication == '3' ? 'checked' : '')) :
                                            (old('oral_communication') == '3' ? 'checked' : '')); ?> name="oral_communication">
                                            <span  style="margin-left: 2px;">3</span>
                                            <input style="margin-left: 35px;" type="radio" value="4" <?php echo e(empty(old('oral_communication')) ? ($errors->has('oral_communication') ? '' : ($employee->oral_communication == '4' ? 'checked' : '')) :
                                            (old('oral_communication') == '4' ? 'checked' : '')); ?> name="oral_communication">
                                            <span style="margin-left: 2px;">4</span>
                                            <input style="margin-left: 35px;" type="radio" value="5" <?php echo e(empty(old('oral_communication')) ? ($errors->has('oral_communication') ? '' : ($employee->oral_communication == '5' ? 'checked' : '')) :
                                            (old('oral_communication') == '5' ? 'checked' : '')); ?> name="oral_communication">
                                            <span style="margin-left: 2px;">5</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group <?php echo e($errors->has('dress_up') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Eye Contact
                            </label>
                            <div class="col-sm-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <div style="margin-top: 7px;" class="input-group-text">
                                            <input type="radio" value="1" <?php echo e(empty(old('eye_contact')) ? ($errors->has('eye_contact') ? '' : ($employee->eye_contact == '1' ? 'checked' : '')) :
                                            (old('eye_contact') == '1' ? 'checked' : '')); ?> name="eye_contact">
                                            <span style="margin-left: 2px;">1</span>
                                            <input style="margin-left: 35px;" type="radio" value="2" <?php echo e(empty(old('eye_contact')) ? ($errors->has('eye_contact') ? '' : ($employee->eye_contact == '2' ? 'checked' : '')) :
                                            (old('eye_contact') == '2' ? 'checked' : '')); ?> name="eye_contact">
                                            <span style="margin-left: 2px;">2</span>
                                            <input style="margin-left: 35px;" type="radio" value="3" <?php echo e(empty(old('eye_contact')) ? ($errors->has('eye_contact') ? '' : ($employee->eye_contact == '3' ? 'checked' : '')) :
                                            (old('eye_contact') == '3' ? 'checked' : '')); ?> name="eye_contact">
                                            <span  style="margin-left: 2px;">3</span>
                                            <input style="margin-left: 35px;" type="radio" value="4" <?php echo e(empty(old('eye_contact')) ? ($errors->has('eye_contact') ? '' : ($employee->eye_contact == '4' ? 'checked' : '')) :
                                            (old('eye_contact') == '4' ? 'checked' : '')); ?> name="eye_contact">
                                            <span style="margin-left: 2px;">4</span>
                                            <input style="margin-left: 35px;" type="radio" value="5" <?php echo e(empty(old('eye_contact')) ? ($errors->has('eye_contact') ? '' : ($employee->eye_contact == '5' ? 'checked' : '')) :
                                            (old('eye_contact') == '5' ? 'checked' : '')); ?> name="eye_contact">
                                            <span style="margin-left: 2px;">5</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <label class="col-sm-2 control-label">Language Proficiency</label>

                            <div class="col-sm-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <div style="margin-top: 7px;" class="input-group-text">
                                            <input type="radio" value="1"<?php echo e(empty(old('language_proficiency')) ? ($errors->has('language_proficiency') ? '' : ($employee->language_proficiency == '1' ? 'checked' : '')) :
                                            (old('language_proficiency') == '1' ? 'checked' : '')); ?> name="language_proficiency">
                                            <span style="margin-left: 2px;">1</span>
                                            <input style="margin-left: 35px;" type="radio" value="2" <?php echo e(empty(old('language_proficiency')) ? ($errors->has('language_proficiency') ? '' : ($employee->language_proficiency == '2' ? 'checked' : '')) :
                                            (old('language_proficiency') == '2' ? 'checked' : '')); ?> name="language_proficiency">
                                            <span style="margin-left: 2px;">2</span>
                                            <input style="margin-left: 35px;" type="radio" value="3" <?php echo e(empty(old('language_proficiency')) ? ($errors->has('language_proficiency') ? '' : ($employee->language_proficiency == '3' ? 'checked' : '')) :
                                            (old('language_proficiency') == '3' ? 'checked' : '')); ?> name="language_proficiency">
                                            <span  style="margin-left: 2px;">3</span>
                                            <input style="margin-left: 35px;" type="radio" value="4" <?php echo e(empty(old('language_proficiency')) ? ($errors->has('language_proficiency') ? '' : ($employee->language_proficiency == '4' ? 'checked' : '')) :
                                            (old('language_proficiency') == '4' ? 'checked' : '')); ?> name="language_proficiency">
                                            <span style="margin-left: 2px;">4</span>
                                            <input style="margin-left: 35px;" type="radio" value="5" <?php echo e(empty(old('language_proficiency')) ? ($errors->has('language_proficiency') ? '' : ($employee->language_proficiency == '5' ? 'checked' : '')) :
                                            (old('language_proficiency') == '5' ? 'checked' : '')); ?> name="language_proficiency">
                                            <span style="margin-left: 2px;">5</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div style="text-align: center;margin-bottom: 10px;margin-top: 10px;" class="section">
                                    <strong><u>Skill</u></strong>
                                </div>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('dress_up') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Computer Skill
                            </label>
                            <div class="col-sm-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <div style="margin-top: 7px;" class="input-group-text">
                                            <input type="radio" value="1" <?php echo e(empty(old('computer_skill')) ? ($errors->has('computer_skill') ? '' : ($employee->computer_skill == '1' ? 'checked' : '')) :
                                            (old('computer_skill') == '1' ? 'checked' : '')); ?> name="computer_skill">
                                            <span style="margin-left: 2px;">1</span>
                                            <input style="margin-left: 35px;" type="radio" value="2" <?php echo e(empty(old('computer_skill')) ? ($errors->has('computer_skill') ? '' : ($employee->computer_skill == '2' ? 'checked' : '')) :
                                            (old('computer_skill') == '2' ? 'checked' : '')); ?> name="computer_skill">
                                            <span style="margin-left: 2px;">2</span>
                                            <input style="margin-left: 35px;" type="radio" value="3" <?php echo e(empty(old('computer_skill')) ? ($errors->has('computer_skill') ? '' : ($employee->computer_skill == '3' ? 'checked' : '')) :
                                            (old('computer_skill') == '3' ? 'checked' : '')); ?> name="computer_skill">
                                            <span  style="margin-left: 2px;">3</span>
                                            <input style="margin-left: 35px;" type="radio" value="4" <?php echo e(empty(old('computer_skill')) ? ($errors->has('computer_skill') ? '' : ($employee->computer_skill == '4' ? 'checked' : '')) :
                                            (old('computer_skill') == '4' ? 'checked' : '')); ?> name="computer_skill">
                                            <span style="margin-left: 2px;">4</span>
                                            <input style="margin-left: 35px;" type="radio" value="5" <?php echo e(empty(old('computer_skill')) ? ($errors->has('computer_skill') ? '' : ($employee->computer_skill == '5' ? 'checked' : '')) :
                                            (old('computer_skill') == '5' ? 'checked' : '')); ?> name="computer_skill">
                                            <span style="margin-left: 2px;">5</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <label class="col-sm-2 control-label">Interpersonal Skill</label>

                            <div class="col-sm-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <div style="margin-top: 7px;" class="input-group-text">
                                            <input type="radio" value="1" <?php echo e(empty(old('interpersonal_skill')) ? ($errors->has('interpersonal_skill') ? '' : ($employee->interpersonal_skill == '1' ? 'checked' : '')) :
                                            (old('interpersonal_skill') == '1' ? 'checked' : '')); ?> name="interpersonal_skill">
                                            <span style="margin-left: 2px;">1</span>
                                            <input style="margin-left: 35px;" type="radio" value="2" <?php echo e(empty(old('interpersonal_skill')) ? ($errors->has('interpersonal_skill') ? '' : ($employee->interpersonal_skill == '2' ? 'checked' : '')) :
                                            (old('interpersonal_skill') == '2' ? 'checked' : '')); ?> name="interpersonal_skill">
                                            <span style="margin-left: 2px;">2</span>
                                            <input style="margin-left: 35px;" type="radio" value="3" <?php echo e(empty(old('interpersonal_skill')) ? ($errors->has('interpersonal_skill') ? '' : ($employee->interpersonal_skill == '3' ? 'checked' : '')) :
                                            (old('interpersonal_skill') == '3' ? 'checked' : '')); ?> name="interpersonal_skill">
                                            <span  style="margin-left: 2px;">3</span>
                                            <input style="margin-left: 35px;" type="radio" value="4" <?php echo e(empty(old('interpersonal_skill')) ? ($errors->has('interpersonal_skill') ? '' : ($employee->interpersonal_skill == '4' ? 'checked' : '')) :
                                            (old('interpersonal_skill') == '4' ? 'checked' : '')); ?> name="interpersonal_skill">
                                            <span style="margin-left: 2px;">4</span>
                                            <input style="margin-left: 35px;" type="radio" value="5" <?php echo e(empty(old('interpersonal_skill')) ? ($errors->has('interpersonal_skill') ? '' : ($employee->interpersonal_skill == '5' ? 'checked' : '')) :
                                            (old('interpersonal_skill') == '5' ? 'checked' : '')); ?> name="interpersonal_skill">
                                            <span style="margin-left: 2px;">5</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div style="text-align: center;margin-bottom: 10px;margin-top: 10px;" class="section">
                                    <strong><u>KNOWLEDGE</u></strong>
                                </div>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('job_knowledge') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Job Knowledge
                            </label>
                            <div class="col-sm-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <div style="margin-top: 7px;" class="input-group-text">
                                            <input type="radio" value="1" <?php echo e(empty(old('job_knowledge')) ? ($errors->has('job_knowledge') ? '' : ($employee->job_knowledge == '1' ? 'checked' : '')) :
                                            (old('job_knowledge') == '1' ? 'checked' : '')); ?> name="job_knowledge">
                                            <span style="margin-left: 2px;">1</span>
                                            <input style="margin-left: 35px;" type="radio" value="2" <?php echo e(empty(old('job_knowledge')) ? ($errors->has('job_knowledge') ? '' : ($employee->job_knowledge == '2' ? 'checked' : '')) :
                                            (old('job_knowledge') == '2' ? 'checked' : '')); ?> name="job_knowledge">
                                            <span style="margin-left: 2px;">2</span>
                                            <input style="margin-left: 35px;" type="radio" value="3" <?php echo e(empty(old('job_knowledge')) ? ($errors->has('job_knowledge') ? '' : ($employee->job_knowledge == '3' ? 'checked' : '')) :
                                            (old('job_knowledge') == '3' ? 'checked' : '')); ?> name="job_knowledge">
                                            <span  style="margin-left: 2px;">3</span>
                                            <input style="margin-left: 35px;" type="radio" value="4" <?php echo e(empty(old('job_knowledge')) ? ($errors->has('job_knowledge') ? '' : ($employee->job_knowledge == '4' ? 'checked' : '')) :
                                            (old('job_knowledge') == '4' ? 'checked' : '')); ?> name="job_knowledge">
                                            <span style="margin-left: 2px;">4</span>
                                            <input style="margin-left: 35px;" type="radio" value="5" <?php echo e(empty(old('job_knowledge')) ? ($errors->has('job_knowledge') ? '' : ($employee->job_knowledge == '5' ? 'checked' : '')) :
                                            (old('job_knowledge') == '5' ? 'checked' : '')); ?> name="job_knowledge">
                                            <span style="margin-left: 2px;">5</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <label class="col-sm-2 control-label">Genetal Knowledge</label>

                            <div class="col-sm-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <div style="margin-top: 7px;" class="input-group-text">
                                            <input type="radio" value="1" <?php echo e(empty(old('general_knowledge')) ? ($errors->has('general_knowledge') ? '' : ($employee->general_knowledge == '1' ? 'checked' : '')) :
                                            (old('general_knowledge') == '1' ? 'checked' : '')); ?> name="general_knowledge">
                                            <span style="margin-left: 2px;">1</span>
                                            <input style="margin-left: 35px;" type="radio" value="2" <?php echo e(empty(old('general_knowledge')) ? ($errors->has('general_knowledge') ? '' : ($employee->general_knowledge == '2' ? 'checked' : '')) :
                                            (old('general_knowledge') == '2' ? 'checked' : '')); ?> name="general_knowledge">
                                            <span style="margin-left: 2px;">2</span>
                                            <input style="margin-left: 35px;" type="radio" value="3" <?php echo e(empty(old('general_knowledge')) ? ($errors->has('general_knowledge') ? '' : ($employee->general_knowledge == '3' ? 'checked' : '')) :
                                            (old('general_knowledge') == '3' ? 'checked' : '')); ?> name="general_knowledge">
                                            <span  style="margin-left: 2px;">3</span>
                                            <input style="margin-left: 35px;" type="radio" value="4" <?php echo e(empty(old('general_knowledge')) ? ($errors->has('general_knowledge') ? '' : ($employee->general_knowledge == '4' ? 'checked' : '')) :
                                            (old('general_knowledge') == '4' ? 'checked' : '')); ?> name="general_knowledge">
                                            <span style="margin-left: 2px;">4</span>
                                            <input style="margin-left: 35px;" type="radio" value="5" <?php echo e(empty(old('general_knowledge')) ? ($errors->has('general_knowledge') ? '' : ($employee->general_knowledge == '5' ? 'checked' : '')) :
                                            (old('general_knowledge') == '5' ? 'checked' : '')); ?> name="general_knowledge">
                                            <span style="margin-left: 2px;">5</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div style="text-align: center;margin-bottom: 10px;margin-top: 10px;" class="section">
                                    <strong><u>OTHERS</u></strong>
                                </div>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('family_background') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Family Background</label>
                            <div class="col-sm-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <div style="margin-top: 7px;" class="input-group-text">
                                            <input type="radio" value="1" <?php echo e(empty(old('family_background')) ? ($errors->has('family_background') ? '' : ($employee->family_background == '1' ? 'checked' : '')) :
                                            (old('family_background') == '1' ? 'checked' : '')); ?> name="family_background">
                                            <span style="margin-left: 2px;">1</span>
                                            <input style="margin-left: 35px;" type="radio" value="2" <?php echo e(empty(old('family_background')) ? ($errors->has('family_background') ? '' : ($employee->family_background == '2' ? 'checked' : '')) :
                                            (old('family_background') == '2' ? 'checked' : '')); ?> name="family_background">
                                            <span style="margin-left: 2px;">2</span>
                                            <input style="margin-left: 35px;" type="radio" value="3" <?php echo e(empty(old('family_background')) ? ($errors->has('family_background') ? '' : ($employee->family_background == '3' ? 'checked' : '')) :
                                            (old('family_background') == '3' ? 'checked' : '')); ?> name="family_background">
                                            <span  style="margin-left: 2px;">3</span>
                                            <input style="margin-left: 35px;" type="radio" value="4" <?php echo e(empty(old('family_background')) ? ($errors->has('family_background') ? '' : ($employee->family_background == '4' ? 'checked' : '')) :
                                            (old('family_background') == '4' ? 'checked' : '')); ?> name="family_background">
                                            <span style="margin-left: 2px;">4</span>
                                            <input style="margin-left: 35px;" type="radio" value="5" <?php echo e(empty(old('family_background')) ? ($errors->has('family_background') ? '' : ($employee->family_background == '5' ? 'checked' : '')) :
                                            (old('family_background') == '5' ? 'checked' : '')); ?> name="family_background">
                                            <span style="margin-left: 2px;">5</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <label class="col-sm-2 control-label">Wllingness to Learn</label>

                            <div class="col-sm-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <div style="margin-top: 7px;" class="input-group-text">
                                            <input type="radio" value="1" <?php echo e(empty(old('wllingness_to_learn')) ? ($errors->has('wllingness_to_learn') ? '' : ($employee->wllingness_to_learn == '1' ? 'checked' : '')) :
                                            (old('wllingness_to_learn') == '1' ? 'checked' : '')); ?> name="wllingness_to_learn">
                                            <span style="margin-left: 2px;">1</span>
                                            <input style="margin-left: 35px;" type="radio" value="2" <?php echo e(empty(old('wllingness_to_learn')) ? ($errors->has('wllingness_to_learn') ? '' : ($employee->wllingness_to_learn == '2' ? 'checked' : '')) :
                                            (old('wllingness_to_learn') == '2' ? 'checked' : '')); ?> name="wllingness_to_learn">
                                            <span style="margin-left: 2px;">2</span>
                                            <input style="margin-left: 35px;" type="radio" value="3" <?php echo e(empty(old('wllingness_to_learn')) ? ($errors->has('wllingness_to_learn') ? '' : ($employee->wllingness_to_learn == '3' ? 'checked' : '')) :
                                            (old('wllingness_to_learn') == '3' ? 'checked' : '')); ?> name="wllingness_to_learn">
                                            <span  style="margin-left: 2px;">3</span>
                                            <input style="margin-left: 35px;" type="radio" value="4" <?php echo e(empty(old('wllingness_to_learn')) ? ($errors->has('wllingness_to_learn') ? '' : ($employee->wllingness_to_learn == '4' ? 'checked' : '')) :
                                            (old('wllingness_to_learn') == '4' ? 'checked' : '')); ?>  name="wllingness_to_learn">
                                            <span style="margin-left: 2px;">4</span>
                                            <input style="margin-left: 35px;" type="radio" value="5" <?php echo e(empty(old('wllingness_to_learn')) ? ($errors->has('wllingness_to_learn') ? '' : ($employee->wllingness_to_learn == '5' ? 'checked' : '')) :
                                            (old('wllingness_to_learn') == '5' ? 'checked' : '')); ?> name="wllingness_to_learn">
                                            <span style="margin-left: 2px;">5</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group <?php echo e($errors->has('long_term_objectives') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Long term Objectives
                            </label>
                            <div class="col-sm-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <div style="margin-top: 7px;" class="input-group-text">
                                            <input type="radio" value="1" <?php echo e(empty(old('long_term_objectives')) ? ($errors->has('long_term_objectives') ? '' : ($employee->long_term_objectives == '1' ? 'checked' : '')) :
                                            (old('long_term_objectives') == '1' ? 'checked' : '')); ?> name="long_term_objectives">
                                            <span style="margin-left: 2px;">1</span>
                                            <input style="margin-left: 35px;" type="radio" value="2" <?php echo e(empty(old('long_term_objectives')) ? ($errors->has('long_term_objectives') ? '' : ($employee->long_term_objectives == '2' ? 'checked' : '')) :
                                            (old('long_term_objectives') == '2' ? 'checked' : '')); ?> name="long_term_objectives">
                                            <span style="margin-left: 2px;">2</span>
                                            <input style="margin-left: 35px;" type="radio" value="3" <?php echo e(empty(old('long_term_objectives')) ? ($errors->has('long_term_objectives') ? '' : ($employee->long_term_objectives == '3' ? 'checked' : '')) :
                                            (old('long_term_objectives') == '3' ? 'checked' : '')); ?> name="long_term_objectives">
                                            <span  style="margin-left: 2px;">3</span>
                                            <input style="margin-left: 35px;" type="radio" value="4" <?php echo e(empty(old('long_term_objectives')) ? ($errors->has('long_term_objectives') ? '' : ($employee->long_term_objectives == '4' ? 'checked' : '')) :
                                            (old('long_term_objectives') == '4' ? 'checked' : '')); ?> name="long_term_objectives">
                                            <span style="margin-left: 2px;">4</span>
                                            <input style="margin-left: 35px;" type="radio" value="5" <?php echo e(empty(old('long_term_objectives')) ? ($errors->has('long_term_objectives') ? '' : ($employee->long_term_objectives == '5' ? 'checked' : '')) :
                                            (old('long_term_objectives') == '5' ? 'checked' : '')); ?> name="long_term_objectives">
                                            <span style="margin-left: 2px;">5</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <label class="col-sm-2 control-label">Team Skill</label>

                            <div class="col-sm-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <div style="margin-top: 7px;" class="input-group-text">
                                            <input type="radio" value="1" <?php echo e(empty(old('team_skill')) ? ($errors->has('team_skill') ? '' : ($employee->team_skill == '1' ? 'checked' : '')) :
                                            (old('team_skill') == '5' ? 'checked' : '')); ?> name="team_skill">
                                            <span style="margin-left: 2px;">1</span>
                                            <input style="margin-left: 35px;" type="radio" value="2" <?php echo e(empty(old('team_skill')) ? ($errors->has('team_skill') ? '' : ($employee->team_skill == '2' ? 'checked' : '')) :
                                            (old('team_skill') == '5' ? 'checked' : '')); ?> name="team_skill">
                                            <span style="margin-left: 2px;">2</span>
                                            <input style="margin-left: 35px;" type="radio" value="3" <?php echo e(empty(old('team_skill')) ? ($errors->has('team_skill') ? '' : ($employee->team_skill == '3' ? 'checked' : '')) :
                                            (old('team_skill') == '5' ? 'checked' : '')); ?> name="team_skill">
                                            <span  style="margin-left: 2px;">3</span>
                                            <input style="margin-left: 35px;" type="radio" value="4" <?php echo e(empty(old('team_skill')) ? ($errors->has('team_skill') ? '' : ($employee->team_skill == '4' ? 'checked' : '')) :
                                            (old('team_skill') == '5' ? 'checked' : '')); ?> name="team_skill">
                                            <span style="margin-left: 2px;">4</span>
                                            <input style="margin-left: 35px;" type="radio" value="5" <?php echo e(empty(old('team_skill')) ? ($errors->has('team_skill') ? '' : ($employee->team_skill == '5' ? 'checked' : '')) :
                                            (old('team_skill') == '5' ? 'checked' : '')); ?> name="team_skill">
                                            <span style="margin-left: 2px;">5</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group <?php echo e($errors->has('working_planing_skill') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Working Planing Skill</label>
                            <div class="col-sm-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <div style="margin-top: 7px;" class="input-group-text">
                                            <input type="radio" value="1" <?php echo e(empty(old('working_planing_skill')) ? ($errors->has('working_planing_skill') ? '' : ($employee->working_planing_skill == '1' ? 'checked' : '')) :
                                            (old('working_planing_skill') == '1' ? 'checked' : '')); ?> name="working_planing_skill">
                                            <span style="margin-left: 2px;">1</span>
                                            <input style="margin-left: 35px;" type="radio" value="2" <?php echo e(empty(old('working_planing_skill')) ? ($errors->has('working_planing_skill') ? '' : ($employee->working_planing_skill == '2' ? 'checked' : '')) :
                                            (old('working_planing_skill') == '2' ? 'checked' : '')); ?> name="working_planing_skill">
                                            <span style="margin-left: 2px;">2</span>
                                            <input style="margin-left: 35px;" type="radio" value="3" <?php echo e(empty(old('working_planing_skill')) ? ($errors->has('working_planing_skill') ? '' : ($employee->working_planing_skill == '3' ? 'checked' : '')) :
                                            (old('working_planing_skill') == '3' ? 'checked' : '')); ?> name="working_planing_skill">
                                            <span  style="margin-left: 2px;">3</span>
                                            <input style="margin-left: 35px;" type="radio" value="4" <?php echo e(empty(old('working_planing_skill')) ? ($errors->has('working_planing_skill') ? '' : ($employee->working_planing_skill == '4' ? 'checked' : '')) :
                                            (old('working_planing_skill') == '4' ? 'checked' : '')); ?> name="working_planing_skill">
                                            <span style="margin-left: 2px;">4</span>
                                            <input style="margin-left: 35px;" type="radio" value="5" <?php echo e(empty(old('working_planing_skill')) ? ($errors->has('working_planing_skill') ? '' : ($employee->working_planing_skill == '5' ? 'checked' : '')) :
                                            (old('working_planing_skill') == '5' ? 'checked' : '')); ?> name="working_planing_skill">
                                            <span style="margin-left: 2px;">5</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="form-group <?php echo e($errors->has('status') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Status *</label>

                            <div class="col-sm-10">

                                <div class="radio" style="display: inline">
                                    <label>
                                        <input type="radio" name="status" value="1" <?php echo e(empty(old('status')) ? ($errors->has('status') ? '' : ($department->status == '1' ? 'checked' : '')) :
                                            (old('status') == '1' ? 'checked' : '')); ?>>
                                        Active
                                    </label>
                                </div>

                                <div class="radio" style="display: inline">
                                    <label>
                                        <input type="radio" name="status" value="0" <?php echo e(empty(old('status')) ? ($errors->has('status') ? '' : ($department->status == '0' ? 'checked' : '')) :
                                            (old('status') == '0' ? 'checked' : '')); ?>>
                                        Inactive
                                    </label>
                                </div>

                                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                    </div>
                    <!-- /.box-body -->

                    <div class="box-footer">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- bootstrap datepicker -->
    <script src="<?php echo e(asset('themes/backend/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>
    <script>
        $(function () {
            //Date picker
            $('#dob').datepicker({
                autoclose: true,
                format: 'yyyy-mm-dd',
                orientation: 'bottom'
            });

            $('.date-picker').datepicker({
                autoclose: true,
                format: 'yyyy-mm-dd',
            });

            var designationSelected = '<?php echo e(empty(old('designation')) ? ($errors->has('designation') ? '' : $employee->designation_id) : old('designation')); ?>';

            $('#department').change(function () {
                var departmentId = $(this).val();
                $('#designation').html('<option value="">Select Designation</option>');

                if (departmentId != '') {
                    $.ajax({
                        method: "GET",
                        url: "<?php echo e(route('get_designation')); ?>",
                        data: { departmentId: departmentId }
                    }).done(function( response ) {
                        $.each(response, function( index, item ) {
                            if (designationSelected == item.id)
                                $('#designation').append('<option value="'+item.id+'" selected>'+item.name+'</option>');
                            else
                                $('#designation').append('<option value="'+item.id+'">'+item.name+'</option>');
                        });
                    });
                }
            });

            $('#department').trigger('change');

            $('#salary_in_jolshiri').change(function () {
                var value = $(this).val();

                if (value == 1) {
                    $('#salary').show();
                } else {
                    $('#salary').hide();
                }
            });

            $('#salary_in_jolshiri').trigger('change');
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\logic_group\resources\views/hr/employee/edit.blade.php ENDPATH**/ ?>