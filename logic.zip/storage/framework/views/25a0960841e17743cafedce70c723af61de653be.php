<?php $__env->startSection('content'); ?>
<?php $__env->startSection('style'); ?>
    <style>
        .tab-content p{
            font-family: Calibri;
        }
    </style>

<?php $__env->stopSection(); ?>
<div class="row">
    <div class="col-md-12">
        <!-- Custom Tabs -->
        <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
                <li class="active"><a href="#profile" data-toggle="tab">Extension Letter</a></li>
            </ul>

            <div class="tab-content">

                <div class="tab-pane active" id="profile">
                    <button class="pull-right btn btn-primary" onclick="getprint('prinarea_profile')">Print</button><br>

                    <div class="row" id="prinarea_profile" style="margin-left: 30px;">

                        <table class="table table-bordered"  >

                            <tr>
                                <div class="row">
                                    <div class="col-xs-4">
                                        <h4><?php echo e(date('d-m-Y', strtotime($candidate->created_at))); ?></h4>
                                        <p><?php echo e($candidate->name); ?></p>
                                        <p><?php echo e($candidate->villaeg); ?></p>
                                        <p><?php echo e($candidate->police_station); ?></p>
                                        <p><?php echo e($candidate->district); ?></p>

                                        <p>Dear <?php echo e($candidate->name); ?>,</p>

                                    </div>
                                </div>
                            </tr>

                            <tr>
                                <h3><u><p style="text-align: center;margin-top: 40px;margin-bottom: 43px;">Offer of Employment</p></u></h3>
                            </tr>
                            <tr>
                                <div class="body">
                                    <?php echo $candidate->employment_offer_letter_body; ?>

                                </div>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
            <!-- /.tab-content -->
        </div>
        <!-- nav-tabs-custom -->
    </div>
    <!-- /.col -->
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>

        var APP_URL = '<?php echo url()->full(); ?>';
        function getprint(prinarea_profile) {

            $('body').html($('#'+prinarea_profile).html());
            window.print();
            window.location.replace(APP_URL)
        }
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\logic_new\resources\views/hr/employment_offer_letter/page.blade.php ENDPATH**/ ?>