<?php $__env->startSection('style'); ?>
    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo e(asset('themes/backend/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    Candidate Details
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <!-- Custom Tabs -->
            <div class="nav-tabs-custom">
                <ul class="nav nav-tabs">
                    <li><a href="<?php echo e(route('candidate_evalution_form.details',['candidate' => $candidate->id])); ?>">Personal Information</a></li>
                    <li><a href="<?php echo e(route('academic_and_training.details', ['candidate' => $candidate->id])); ?>">Academic & Training</a></li>
                    <li><a href="<?php echo e(route('job_information.details',['candidate' => $candidate->id])); ?>">Job Information</a></li>
                    <li class="active"><a href="<?php echo e(route('employee_wise_attendance',['candidate' => $candidate->id])); ?>">Attendance</a></li>
                    <li><a href="<?php echo e(route('payroll.employee_wise.leave',['candidate' => $candidate->id])); ?>">Leave</a></li>
                    <li><a href="<?php echo e(route('payroll.employee.wise.salary.slip',['candidate' => $candidate->id])); ?>">Salary</a></li>
                    <li><a href="<?php echo e(route('payroll.employee.wise.loan',['candidate' => $candidate->id])); ?>">Loan</a></li>
                    <li><a href="<?php echo e(route('candidate_evaluation',['candidate' => $candidate->id])); ?>">Evalution</a></li>
                    <li><a href="#userAccount">User Account</a></li>
                    <li><a href="<?php echo e(route('payroll.employee_wise.report',['candidate' => $candidate->id])); ?>">Report</a></li>
                </ul>

                <div class="tab-content">
                    <ul>
                        <a class="btn btn-primary btn-sm" href="<?php echo e(route('attendance_manually_input',['candidate' => $candidate->id])); ?>">Manual Input</a>

                    </ul>


                    <div class="tab-pane active" id="profile">
                        <button class="pull-right btn btn-primary" onclick="getprint('prinarea_profile')">Print</button><br>
                        <u><h4 class="text-center">Attendance Information</h4></u>
                        <div class="row" id="prinarea_profile">
                            <div class="col-md-12">
                                <table class="table table-bordered">
                                    <tr>
                                        <th>Employee Id</th>
                                        <th>Present/Absent</th>
                                        <th>Present Date</th>
                                        <th>Intime</th>
                                        <th>Early In time</th>
                                        <th>Late time</th>
                                        <th>Outtime</th>
                                        <th>Early Out time</th>
                                        <th>Late Out time</th>
                                        <th>Total Hours</th>
                                        <th>Note</th>
                                        <th>Action</th>
                                    </tr>
                                    <?php
                                    $totalOvertime = 0;
                                    ?>
                                    <?php
                                        $totalPaymentOur = 0;
                                    ?>
                                    <?php
                                        $totalLateTime = 0;
                                    ?>

                                    <?php $__currentLoopData = $employeeWiseAttendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employeeWiseAttendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>

                                        <td><?php echo e($employeeWiseAttendance->employee_id??''); ?></td>
                                        <td>
                                            <?php if($employeeWiseAttendance->status == 1): ?>
                                                Present
                                            <?php else: ?>
                                                Absent
                                            <?php endif; ?>

                                        </td>
                                        <td><?php echo e($employeeWiseAttendance->process_date??''); ?></td>
                                        <td><?php echo e((date('H:i:s', strtotime($employeeWiseAttendance->intime??'')))); ?></td>
                                        <td><?php echo e((date('H:i:s', strtotime($employeeWiseAttendance->early_in_time??'00.00.00')))); ?></td>
                                        <td>
                                            <?php echo e((date('H:i:s', strtotime($employeeWiseAttendance->late_time??'00.00.00')))); ?>

                                            <?php
                                                $totalLateTime = $totalLateTime + strtotime("1970-01-01 $employeeWiseAttendance->late_time UTC")
                                            ?>
                                        </td>
                                        <td><?php echo e((date('H:i:s', strtotime($employeeWiseAttendance->outtime??'')))); ?></td>
                                        <td><?php echo e((date('H:i:s', strtotime($employeeWiseAttendance->early_out_time??'00.00.00')))); ?></td>
                                        <td>
                                            <?php echo e((date('H:i:s', strtotime($employeeWiseAttendance->over_time??'00.00.00')))); ?>


                                            <?php
                                                $totalOvertime = $totalOvertime + strtotime("1970-01-01 $employeeWiseAttendance->over_time UTC")
                                            ?>

                                        </td>
                                        <td>
                                            <?php echo e($employeeWiseAttendance->total_hours??'00.00.00'); ?>


                                            <?php
                                                $totalPaymentOur = $totalPaymentOur + strtotime("1970-01-01 $employeeWiseAttendance->total_hours UTC")
                                            ?>

                                        </td>
                                        <td><?php echo e($employeeWiseAttendance->remark??''); ?></td>
                                        <td>
                                            <a class="btn btn-success btn-sm btn-overtime-approved" role="button" data-id="<?php echo e($employeeWiseAttendance->id); ?>">Approved Hours</a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td><?php echo e((gmdate("H:i:s", $totalLateTime))); ?></td>
                                        <td></td>
                                        <td></td>
                                        <td><?php echo e((gmdate("H:i:s", $totalOvertime))); ?></td>
                                        <td><?php echo e((gmdate("H:i:s", $totalPaymentOur))); ?></td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.tab-content -->
            </div>
            <!-- nav-tabs-custom -->
        </div>
        <!-- /.col -->
    </div>

    <div class="modal" tabindex="-1" role="dialog" id="modal-overtime-approved">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Please Salary Update And Mention For Month Or Cancel</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="modal-approved-form" enctype="multipart/form-data" name="modal_approved_form">
                        <div class="form-group">
                            <label>Employee ID</label>
                            <input class="form-control" id="candidate-id" name="candidate_id" readonly>
                        </div>

                        <div class="form-group">
                            <label>OverTime Update</label>
                            <input type="text" class="form-control" id="overtime" name="overtime">
                        </div>

                        <div class="form-group">
                            <label>For Date *</label>
                            <div class="input-group date">
                                <div class="input-group-addon">
                                    <i class="fa fa-calendar"></i>
                                </div>
                                <input type="date" class="form-control pull-right" name="for_date" value="<?php echo e(date('Y-m-d')); ?>" autocomplete="off">
                            </div>
                            <!-- /.input group -->
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary " id="modal-btn-approved">Approved</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- DataTables -->
    <script src="<?php echo e(asset('themes/backend/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('themes/backend/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
    <script>

        $('body').on('click', '.btn-overtime-approved', function () {
            var employeeId = $(this).data('id');

            $.ajax({
                method: "GET",
                url: "<?php echo e(route('get_overtime')); ?>",
                data: { employeeId: employeeId }
            }).done(function( response ) {
                console.log(response);

                $('#candidate-id').val(response.employee_id);
                $('#overtime').val(response.over_time);


                $('#modal-overtime-approved').modal('show');
            });
        });
        $('#modal-btn-approved').click(function () {
            var formData = new FormData($('#modal-approved-form')[0]);

            $.ajax({
                type: "POST",
                url: "<?php echo e(route('overtime_approved.post')); ?>",
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                        $('#modal-overtime-approved').modal('hide');
                        Swal.fire(
                            'Approved!',
                            response.message,
                            'success'
                        ).then((result) => {
                            location.reload();
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Oops...',
                            text: response.message,
                        });
                    }
                }
            });
        });

        var APP_URL = '<?php echo url()->full(); ?>';
        function getprint(prinarea_profile) {

            $('body').html($('#'+prinarea_profile).html());
            window.print();
            window.location.replace(APP_URL)
        }
        function getprintleave(prinarea_leave) {

            $('body').html($('#'+prinarea_leave).html());
            window.print();
            window.location.replace(APP_URL)
        }
        function getprintleave(prinarea_salary) {

            $('body').html($('#'+prinarea_salary).html());
            window.print();
            window.location.replace(APP_URL)
        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/itautoma/public_html/logic/resources/views/hr/attendance/employee_wise_attendance.blade.php ENDPATH**/ ?>