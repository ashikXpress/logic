<?php $__env->startSection('style'); ?>
    <!-- bootstrap datepicker -->
    <link rel="stylesheet" href="<?php echo e(asset('themes/backend/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>">
    <!-- Select2 -->
    <link rel="stylesheet" href="<?php echo e(asset('themes/backend/bower_components/select2/dist/css/select2.min.css')); ?>">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    Create Loan
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(Session::has('message')): ?>
        <div class="alert alert-success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <?php echo e(Session::get('message')); ?>

        </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <ul class="nav nav-tabs">
                    <li><a href="<?php echo e(route('candidate_evalution_form.details',['candidate' => $candidate->id])); ?>">Personal Information</a></li>
                    <li><a href="<?php echo e(route('academic_and_training.details', ['candidate' => $candidate->id])); ?>">Academic Information</a></li>

                    <li><a href="<?php echo e(route('job_information.details',['candidate' => $candidate->id])); ?>">Job Information</a></li>
                    <li><a href="<?php echo e(route('employee_wise_attendance',['candidate' => $candidate->id])); ?>">Attendance</a></li>
                    <li><a href="<?php echo e(route('payroll.employee_wise.leave',['candidate' => $candidate->id])); ?>">Leave</a></li>
                    <li><a href="<?php echo e(route('payroll.employee.wise.salary.slip',['candidate' => $candidate->id])); ?>">Salary</a></li>
                    <li class="active"><a href="<?php echo e(route('payroll.employee.wise.loan',['candidate' => $candidate->id])); ?>">Loan</a></li>
                    <li><a href="<?php echo e(route('candidate_evaluation',['candidate' => $candidate->id])); ?>">Evalution</a></li>
                    <li><a href="#leave">User Account</a></li>
                    <li><a href="<?php echo e(route('payroll.employee_wise.report',['candidate' => $candidate->id])); ?>">Report</a></li>
                </ul>
                <div class="box-header with-border">
                    <h3 class="box-title">Employee Wise Loan Report</h3>
                </div>
                <!-- /.box-header -->

                <div class="box-body">
                    <div class="loan_button">
                        <div class="row">
                            <div class="col-md-4">
                                <a href="<?php echo e(route('previous_loan',['candidate' => $candidate->id])); ?>"><button type="button" class="btn btn-success">Previous Loan</button> </a>
                                <a href="<?php echo e(route('current_loan',['candidate' => $candidate->id])); ?>"><button type="button" class="btn btn-success" style="margin-left: 20px">Current Loan</button> </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="row">
        <div class="col-sm-12" style="min-height:300px">
            <?php if($previous_loans != null): ?>
                <section class="panel">

                    <div class="panel-body">
                        <button class="pull-right btn btn-primary" onclick="getprint('prinarea')">Print</button><br><hr>

                        <div class="adv-table" id="prinarea">

                            <div class="row">
                                <div class="col-xs-2">
                                    <div class="logo" style="margin-left: 16px;">
                                        <div class="logo-img">
                                            <img src="<?php echo e(asset('img/logo.png')); ?>" alt="" height="90px" width="90px">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xs-8">
                                    <div style= text-align:center;">
                                        <h2>Logic Group</h2>
                                        <h4>General Loan</h4>
                                    </div>
                                </div>
                            </div>






                            <div style="clear: both">
                                <table class="table table-bordered" style="width:100%; float:left">



                                    <tr>
                                        <th class="text-center" width="25%">Employee Id</th>
                                        <td class="text-center" width="25%"><?php echo e($employee_id->employee_id); ?></td>
                                        <th class="text-center" width="25%">Department</th>
                                        <td class="text-center" width="25%"><?php echo e($employee_id->employee->department->name); ?></td>
                                    </tr>
                                    <tr>
                                        <th class="text-center" width="25%">Employee Name</th>
                                        <td class="text-center" width="25%"><?php echo e($employee_id->employee->name); ?></td>
                                        <th class="text-center" width="25%">Designation</th>
                                        <td class="text-center" width="25%"><?php echo e($employee_id->employee->designation->name); ?></td>
                                    </tr>
                                </table>
                                <table class="table table-bordered">
                                    <tr>
                                        <th>SI No</th>
                                        <th>ID No</th>
                                        <th>Amount</th>
                                        <th>Interest(Persent)</th>
                                        <th>Total Payble Amount</th>
                                        <th>Install Month</th>
                                        <th>Per Month Payble</th>
                                        <th>Paid</th>
                                        <th>Due</th>
                                        <th>Loan Date</th>
                                        <th>Note</th>
                                    </tr>
                                    <?php $__currentLoopData = $previous_loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $previous_loan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($previous_loan->employee_id); ?></td>
                                        <td><?php echo e($previous_loan->amount); ?></td>
                                        <td><?php echo e($previous_loan->interest); ?></td>
                                        <td><?php echo e($previous_loan->total_payble_amount); ?></td>
                                        <td><?php echo e($previous_loan->installment_month); ?></td>
                                        <td><?php echo e($previous_loan->per_month_payble_amount); ?></td>
                                        <td><?php echo e($previous_loan->paid); ?></td>
                                        <td><?php echo e($previous_loan->due); ?></td>
                                        <td><?php echo e($previous_loan->loan_date); ?></td>
                                        <td><?php echo e($previous_loan->note); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            </div>
                        </div>
                    </div>
                </section>
            <?php endif; ?>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-12" style="min-height:300px">
            <?php if($previous_pfloans != null): ?>
                <section class="panel">

                    <div class="panel-body">
                        <button class="pull-right btn btn-primary" onclick="getprint('prinarea')">Print</button><br><hr>

                        <div class="adv-table" id="prinarea">

                            <div class="row">
                                <div class="col-xs-2">
                                    <div class="logo" style="margin-left: 16px;">
                                        <div class="logo-img">
                                            <img src="<?php echo e(asset('img/logo.png')); ?>" alt="" height="90px" width="90px">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xs-8">
                                    <div style= text-align:center;">
                                        <h2>Logic Group</h2>
                                        <h4>provident fund(PF) Loan</h4>
                                    </div>
                                </div>
                            </div>
                            
                            
                            
                            
                            

                            <div style="clear: both">
                                <table class="table table-bordered" style="width:100%; float:left">



                                    <tr>
                                        <th class="text-center" width="25%">Employee Id</th>
                                        <td class="text-center" width="25%"><?php echo e($employee_id->employee_id); ?></td>
                                        <th class="text-center" width="25%">Department</th>
                                        <td class="text-center" width="25%"><?php echo e($employee_id->employee->department->name); ?></td>
                                    </tr>
                                    <tr>
                                        <th class="text-center" width="25%">Employee Name</th>
                                        <td class="text-center" width="25%"><?php echo e($employee_id->employee->name); ?></td>
                                        <th class="text-center" width="25%">Designation</th>
                                        <td class="text-center" width="25%"><?php echo e($employee_id->employee->designation->name); ?></td>
                                    </tr>
                                </table>
                                <table class="table table-bordered">
                                    <tr>
                                        <th>SI No</th>
                                        <th>ID No</th>
                                        <th>Amount</th>
                                        <th>Interest(Persent)</th>
                                        <th>Total Payble Amount</th>
                                        <th>Install Month</th>
                                        <th>Per Month Payble</th>
                                        <th>Paid</th>
                                        <th>Due</th>
                                        <th>Loan Date</th>
                                        <th>Note</th>
                                    </tr>
                                    <?php $__currentLoopData = $previous_pfloans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $previous_pfloan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($previous_pfloan->employee_id); ?></td>
                                            <td><?php echo e($previous_pfloan->amount); ?></td>
                                            <td><?php echo e($previous_pfloan->interest); ?></td>
                                            <td><?php echo e($previous_pfloan->total_payble_amount); ?></td>
                                            <td><?php echo e($previous_pfloan->installment_month); ?></td>
                                            <td><?php echo e($previous_pfloan->per_month_payble_amount); ?></td>
                                            <td><?php echo e($previous_pfloan->paid); ?></td>
                                            <td><?php echo e($previous_pfloan->due); ?></td>
                                            <td><?php echo e($previous_pfloan->loan_date); ?></td>
                                            <td><?php echo e($previous_pfloan->note); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            </div>
                        </div>
                    </div>
                </section>
            <?php endif; ?>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-12" style="min-height:300px">
            <?php if($previous_skrploans != null): ?>
                <section class="panel">

                    <div class="panel-body">
                        <button class="pull-right btn btn-primary" onclick="getprint('prinarea')">Print</button><br><hr>

                        <div class="adv-table" id="prinarea">

                            <div class="row">
                                <div class="col-xs-2">
                                    <div class="logo" style="margin-left: 16px;">
                                        <div class="logo-img">
                                            <img src="<?php echo e(asset('img/logo.png')); ?>" alt="" height="90px" width="90px">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xs-8">
                                    <div style= text-align:center;">
                                        <h2>Logic Group</h2>
                                        <h4>SKRP Loan</h4>
                                    </div>
                                </div>
                            </div>
                            
                            
                            
                            
                            

                            <div style="clear: both">
                                <table class="table table-bordered" style="width:100%; float:left">



                                    <tr>
                                        <th class="text-center" width="25%">Employee Id</th>
                                        <td class="text-center" width="25%"><?php echo e($employee_id->employee_id); ?></td>
                                        <th class="text-center" width="25%">Department</th>
                                        <td class="text-center" width="25%"><?php echo e($employee_id->employee->department->name); ?></td>
                                    </tr>
                                    <tr>
                                        <th class="text-center" width="25%">Employee Name</th>
                                        <td class="text-center" width="25%"><?php echo e($employee_id->employee->name); ?></td>
                                        <th class="text-center" width="25%">Designation</th>
                                        <td class="text-center" width="25%"><?php echo e($employee_id->employee->designation->name); ?></td>
                                    </tr>
                                </table>
                                <table class="table table-bordered">
                                    <tr>
                                        <th>SI No</th>
                                        <th>ID No</th>
                                        <th>Amount</th>
                                        <th>Interest(Persent)</th>
                                        <th>Total Payble Amount</th>
                                        <th>Install Month</th>
                                        <th>Per Month Payble</th>
                                        <th>Paid</th>
                                        <th>Due</th>
                                        <th>Loan Date</th>
                                        <th>Note</th>
                                    </tr>
                                    <?php $__currentLoopData = $previous_skrploans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $previous_skrploan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($previous_skrploan->employee_id); ?></td>
                                            <td><?php echo e($previous_skrploan->amount); ?></td>
                                            <td><?php echo e($previous_skrploan->interest); ?></td>
                                            <td><?php echo e($previous_skrploan->total_payble_amount); ?></td>
                                            <td><?php echo e($previous_skrploan->installment_month); ?></td>
                                            <td><?php echo e($previous_skrploan->per_month_payble_amount); ?></td>
                                            <td><?php echo e($previous_skrploan->paid); ?></td>
                                            <td><?php echo e($previous_skrploan->due); ?></td>
                                            <td><?php echo e($previous_skrploan->loan_date); ?></td>
                                            <td><?php echo e($previous_skrploan->note); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            </div>
                        </div>
                    </div>
                </section>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <!-- bootstrap datepicker -->
    <script src="<?php echo e(asset('themes/backend/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>
    <!-- Select2 -->
    <script src="<?php echo e(asset('themes/backend/bower_components/select2/dist/js/select2.full.min.js')); ?>"></script>

    <script>
        $(function () {
            //Date picker
            $('#start, #end').datepicker({
                autoclose: true,
                format: 'yyyy-mm-dd'
            });
        });
        //Initialize Select2 Elements
        $('.select2').select2()

        var APP_URL = '<?php echo url()->full(); ?>';
        function getprint(print) {

            $('body').html($('#'+print).html());
            window.print();
            window.location.replace(APP_URL)
        }
    </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\logic\resources\views/payroll/create_loan/employee_wise_loan.blade.php ENDPATH**/ ?>