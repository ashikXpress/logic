<?php $__env->startSection('style'); ?>
    <!-- bootstrap datepicker -->
    <link rel="stylesheet" href="<?php echo e(asset('themes/backend/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>">
    <!-- Select2 -->
    <link rel="stylesheet" href="<?php echo e(asset('themes/backend/bower_components/select2/dist/css/select2.min.css')); ?>">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    Create Loan
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(Session::has('message')): ?>
        <div class="alert alert-success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <?php echo e(Session::get('message')); ?>

        </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <ul class="nav nav-tabs">
                    <li><a href="<?php echo e(route('candidate_evalution_form.details',['candidate' => $candidate->id])); ?>">Personal Information</a></li>
                    <li><a href="<?php echo e(route('academic_and_training.details', ['candidate' => $candidate->id])); ?>">Academic Information</a></li>

                    <li><a href="<?php echo e(route('job_information.details',['candidate' => $candidate->id])); ?>">Job Information</a></li>
                    <li><a href="<?php echo e(route('employee_wise_attendance',['candidate' => $candidate->id])); ?>">Attendance</a></li>
                    <li><a href="<?php echo e(route('payroll.employee_wise.leave',['candidate' => $candidate->id])); ?>">Leave</a></li>
                    <li><a href="<?php echo e(route('payroll.employee.wise.salary.slip',['candidate' => $candidate->id])); ?>">Salary</a></li>
                    <li><a href="<?php echo e(route('payroll.employee.wise.loan',['candidate' => $candidate->id])); ?>">Loan</a></li>
                    <li><a href="<?php echo e(route('candidate_evaluation',['candidate' => $candidate->id])); ?>">Evalution</a></li>
                    <li><a href="#leave">User Account</a></li>
                    <li class="active"><a href="<?php echo e(route('payroll.employee_wise.report',['candidate' => $candidate->id])); ?>">Report</a></li>
                </ul>
                <div class="box-header with-border">
                    <h3 class="box-title">Employee Wise Report</h3>
                </div>
                <!-- /.box-header -->

                <div class="box-body">
                    <div class="loan_button">
                        <div class="row">
                            <div class="col-md-12">


                                <a href="<?php echo e(route('payroll.employee.wise.loan',['candidate' => $candidate->id])); ?>"><button type="button" class="btn btn-primary" style="margin-left: 20px">Loan Report</button> </a>
                                <a href="<?php echo e(route('payroll.employee_wise_attendance_report',['candidate' => $candidate->id])); ?>"><button type="button" class="btn btn-info" style="margin-left: 20px">Attendance Report</button> </a>
                                <a href="<?php echo e(route('payroll.employee_wise_leave_report',['candidate' => $candidate->id])); ?>"><button type="button" class="btn btn-warning" style="margin-left: 20px">Leave Report</button> </a>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
























































































<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <!-- bootstrap datepicker -->
    <script src="<?php echo e(asset('themes/backend/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>
    <!-- Select2 -->
    <script src="<?php echo e(asset('themes/backend/bower_components/select2/dist/js/select2.full.min.js')); ?>"></script>

    <script>
        $(function () {
            //Date picker
            $('#start, #end').datepicker({
                autoclose: true,
                format: 'yyyy-mm-dd'
            });
        });
        //Initialize Select2 Elements
        $('.select2').select2()

        var APP_URL = '<?php echo url()->full(); ?>';
        function getprint(print) {

            $('body').html($('#'+print).html());
            window.print();
            window.location.replace(APP_URL)
        }
    </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\logic\resources\views/payroll/report/employee_wise_report.blade.php ENDPATH**/ ?>