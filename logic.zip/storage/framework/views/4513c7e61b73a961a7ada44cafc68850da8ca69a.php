<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!--Favicon-->
    <link rel="icon" href="<?php echo e(asset('img/favicon.png')); ?>" type="image/x-icon" />

    <!-- Bootstrap 3.3.7 -->
    <link rel="stylesheet" href="<?php echo e(asset('themes/backend/bower_components/bootstrap/dist/css/bootstrap.min.css')); ?>">

    <style>
        #receipt-content{
            font-size: 18px;
        }

        .table-bordered>thead>tr>th, .table-bordered>tbody>tr>th, .table-bordered>tfoot>tr>th, .table-bordered>thead>tr>td, .table-bordered>tbody>tr>td, .table-bordered>tfoot>tr>td {
            border: 1px solid black !important;
        }
    </style>
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <div class="col-xs-4">
            <img src="<?php echo e(asset('img/logo.png')); ?>" height="50px" style="float: left">
            <h2 style="margin: 0px; float: left">RECEIPT</h2>
        </div>

        <div class="col-xs-4 text-center">
            <b>Date: </b> <?php echo e($payment->date->format('j F, Y')); ?>

        </div>

        <div class="col-xs-4 text-right">
            <b>No: </b> <?php echo e($payment->id + 1000); ?>

        </div>
    </div>

    <div class="row" style="margin-top: 20px">
        <div class="col-xs-12">
            <table class="table table-bordered">
                <tr>
                    <th width="20%">
                        <?php if($payment->type == 1): ?>
                            From
                        <?php elseif($payment->type == 2): ?>
                            To
                        <?php endif; ?>
                    </th>
                    <td><?php echo e($payment->salesOrder->client->name); ?></td>
                    <th width="10%">Amount</th>
                    <td width="15%">৳<?php echo e(number_format($payment->amount, 2)); ?></td>
                </tr>

                <tr>
                    <th>Amount (In Word)</th>
                    <td colspan="3"><?php echo e($payment->amount_in_word); ?></td>
                </tr>

                <tr>
                    <th>For Payment of</th>
                    <td colspan="3">Order No. <?php echo e($payment->salesOrder->order_no); ?></td>
                </tr>

                <tr>
                    <th>Paid By</th>
                    <td colspan="3">
                        <?php if($payment->transaction_method == 1): ?>
                            Cash
                        <?php elseif($payment->transaction_method == 3): ?>
                            Mobile Banking
                        <?php else: ?>
                            Bank - <?php echo e($payment->bank->name.' - '.$payment->branch->name.' - '.$payment->account->account_no); ?>

                        <?php endif; ?>
                    </td>
                </tr>

                <?php if($payment->transaction_method == 2): ?>
                    <tr>
                        <th>Cheque No.</th>
                        <td colspan="3"><?php echo e($payment->cheque_no); ?></td>
                    </tr>
                <?php endif; ?>

                <tr>
                    <th>Note</th>
                    <td colspan="3"><?php echo e($payment->note); ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>


<script>
    window.print();
    window.onafterprint = function(){ window.close()};
</script>
</body>
</html>
<?php /**PATH E:\xampp\htdocs\logic_group\resources\views/sale/receipt/payment_print.blade.php ENDPATH**/ ?>