<?php $__env->startSection('style'); ?>
    <!-- bootstrap datepicker -->
    <link rel="stylesheet" href="<?php echo e(asset('themes/backend/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>">

    <style>
        .table-bordered>thead>tr>th, .table-bordered>tbody>tr>th, .table-bordered>tfoot>tr>th, .table-bordered>thead>tr>td, .table-bordered>tbody>tr>td, .table-bordered>tfoot>tr>td {
            border: 1.5px solid #000 !important;
        }
    </style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    Employee Payment  History
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-sm-12" style="min-height:300px">


            <section class="panel">

                <div class="panel-body">
                    <button class="pull-right btn btn-primary" onclick="getprint('prinarea')">Print</button><br><hr>

                    <div class="adv-table" id="prinarea">
                        <div class="table-responsive">

                            <table class="table table-bordered" style="margin-bottom: 0px">
                                <tr>
                                    <th colspan="29" class="text-center">Logic Group BD.</th>
                                </tr>
                                <tr>
                                    <th colspan="29" class="text-center">Moriom Tower, Gangkola, Pabna-6600</th>
                                </tr>



                                <tr>
                                    <th>SL No</th>
                                    <th>Employment Status</th>
                                    <th>Name of Employee</th>
                                    <th>Employee ID</th>
                                    <th>Month</th>
                                    <th>Year</th>
                                    <th>CTC</th>
                                    <th>Basic Salary</th>
                                    <th>House Rent</th>
                                    <th>Conveyance</th>
                                    <th>Medical Expenses</th>
                                    <th>Bonus</th>
                                    <th>Special Allowance</th>
                                    <th>Advance</th>
                                    <th>Transport Allowance</th>
                                    <th>Dinner Allowance</th>
                                    <th>Mobile Bill</th>
                                    <th>Others</th>
                                    <th>Total</th>
                                    <th>Bank Fund</th>
                                    <th>Lone</th>
                                    <th>Penalty</th>
                                    <th>Income Tex</th>
                                    <th>Revenue Stamp</th>
                                    <th>Miscellaneous</th>
                                    <th>Kollan Trust</th>
                                    <th>Total</th>
                                    <th>Net Payble</th>
                                    <th>Deduction Amount History</th>
                                </tr>

                                <?php $__currentLoopData = $salaries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salarie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $gross_salary = $salarie->gross_salary;
                                    ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($salarie->employee->status); ?></td>
                                    <td><?php echo e($salarie->employee->name); ?></td>
                                    <td><?php echo e($salarie->employee->employee_id); ?></td>
                                    <td class="text-center">
                                        <?php if($salarie->month == 1): ?>
                                            <span>January</span>
                                        <?php elseif($salarie->month == 2): ?>
                                            <span>February</span>
                                        <?php elseif($salarie->month == 3): ?>
                                            <span>March</span>
                                        <?php elseif($salarie->month == 4): ?>
                                            <span>April</span>
                                        <?php elseif($salarie->month == 5): ?>
                                            <span>May</span>
                                        <?php elseif($salarie->month == 6): ?>
                                            <span>June</span>
                                        <?php elseif($salarie->month == 7): ?>
                                            <span>July</span>
                                        <?php elseif($salarie->month == 8): ?>
                                            <span>August</span>
                                        <?php elseif($salarie->month == 9): ?>
                                            <span>September</span>
                                        <?php elseif($salarie->month == 10): ?>
                                            <span>October</span>
                                        <?php elseif($salarie->month == 11): ?>
                                            <span>November</span>
                                        <?php else: ?>
                                            <span>December</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($salarie->year); ?></td>
                                    <td><?php echo e($salarie->gross_salary); ?></td>
                                    <td><?php echo e($salarie->basic_salary); ?></td>
                                    <td><?php echo e($salarie->house_rent); ?></td>
                                    <td><?php echo e($salarie->conveyance); ?></td>
                                    <td><?php echo e($salarie->medical); ?></td>
                                    <td>
                                        <?php if($salarie->PaymentHistory($salarie->employee_id,$salarie->month,$salarie->year)): ?>
                                            <?php echo e($salarie->PaymentHistory($salarie->employee_id,$salarie->month,$salarie->year)->bonus??0); ?>

                                            <?php
                                                $gross_salary +=$salarie->PaymentHistory($salarie->employee_id,$salarie->month,$salarie->year)->bonus??0;
                                            ?>
                                        <?php else: ?>
                                            <span>0</span>
                                        <?php endif; ?>

                                    </td>
                                    <td>
                                        <?php if($salarie->PaymentHistory($salarie->employee_id,$salarie->month,$salarie->year)): ?>
                                            <?php echo e($salarie->PaymentHistory($salarie->employee_id,$salarie->month,$salarie->year)->speacial_allowance??0); ?>

                                            <?php
                                                $gross_salary +=$salarie->PaymentHistory($salarie->employee_id,$salarie->month,$salarie->year)->speacial_allowance??0;
                                            ?>
                                        <?php else: ?>
                                            <span>0</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($salarie->PaymentHistory($salarie->employee_id,$salarie->month,$salarie->year)): ?>
                                            <?php echo e($salarie->PaymentHistory($salarie->employee_id,$salarie->month,$salarie->year)->advance??0); ?>

                                            <?php
                                                $gross_salary +=$salarie->PaymentHistory($salarie->employee_id,$salarie->month,$salarie->year)->advance??0;
                                            ?>
                                        <?php else: ?>
                                            <span>0</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($salarie->PaymentHistory($salarie->employee_id,$salarie->month,$salarie->year)): ?>
                                            <?php echo e($salarie->PaymentHistory($salarie->employee_id,$salarie->month,$salarie->year)->transport_allowence??0); ?>

                                            <?php
                                                $gross_salary +=$salarie->PaymentHistory($salarie->employee_id,$salarie->month,$salarie->year)->transport_allowence??0;
                                            ?>
                                        <?php else: ?>
                                            <span>0</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($salarie->PaymentHistory($salarie->employee_id,$salarie->month,$salarie->year)): ?>
                                            <?php echo e($salarie->PaymentHistory($salarie->employee_id,$salarie->month,$salarie->year)->dinner_allowence??0); ?>

                                            <?php
                                                $gross_salary +=$salarie->PaymentHistory($salarie->employee_id,$salarie->month,$salarie->year)->dinner_allowence??0;
                                            ?>
                                        <?php else: ?>
                                            <span>0</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($salarie->PaymentHistory($salarie->employee_id,$salarie->month,$salarie->year)): ?>
                                            <?php echo e($salarie->PaymentHistory($salarie->employee_id,$salarie->month,$salarie->year)->mobile_bill??0); ?>

                                            <?php
                                                $gross_salary +=$salarie->PaymentHistory($salarie->employee_id,$salarie->month,$salarie->year)->mobile_bill??0;
                                            ?>
                                        <?php else: ?>
                                            <span>0</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($salarie->PaymentHistory($salarie->employee_id,$salarie->month,$salarie->year)): ?>
                                            <?php echo e($salarie->PaymentHistory($salarie->employee_id,$salarie->month,$salarie->year)->others??0); ?>

                                            <?php
                                                $gross_salary +=$salarie->PaymentHistory($salarie->employee_id,$salarie->month,$salarie->year)->others??0;
                                            ?>
                                        <?php else: ?>
                                            <span>0</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($gross_salary); ?></td>
                                    <td><?php echo e($salarie->deduction); ?></td>
                                    <td><?php echo e($salarie->loan??0); ?></td>
                                    <td>
                                        <?php if($salarie->PaymentHistory($salarie->employee_id,$salarie->month,$salarie->year)): ?>
                                            <?php echo e($salarie->PaymentHistory($salarie->employee_id,$salarie->month,$salarie->year)->penalty??0); ?>

                                            <?php
                                                $gross_salary -=$salarie->PaymentHistory($salarie->employee_id,$salarie->month,$salarie->year)->penalty??0;
                                            ?>
                                        <?php else: ?>
                                            <span>0</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($salarie->PaymentHistory($salarie->employee_id,$salarie->month,$salarie->year)): ?>
                                            <?php echo e($salarie->PaymentHistory($salarie->employee_id,$salarie->month,$salarie->year)->income_tex??0); ?>

                                            <?php
                                                $gross_salary -=$salarie->PaymentHistory($salarie->employee_id,$salarie->month,$salarie->year)->income_tex??0;
                                            ?>
                                        <?php else: ?>
                                            <span>0</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($salarie->PaymentHistory($salarie->employee_id,$salarie->month,$salarie->year)): ?>
                                            <?php echo e($salarie->PaymentHistory($salarie->employee_id,$salarie->month,$salarie->year)->revenue_stamp??0); ?>

                                            <?php
                                                $gross_salary -=$salarie->PaymentHistory($salarie->employee_id,$salarie->month,$salarie->year)->revenue_stamp??0;
                                            ?>
                                        <?php else: ?>
                                            <span>0</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($salarie->PaymentHistory($salarie->employee_id,$salarie->month,$salarie->year)): ?>
                                            <?php echo e($salarie->PaymentHistory($salarie->employee_id,$salarie->month,$salarie->year)->miscellaneous??0); ?>

                                            <?php
                                                $gross_salary -=$salarie->PaymentHistory($salarie->employee_id,$salarie->month,$salarie->year)->miscellaneous??0;
                                            ?>
                                        <?php else: ?>
                                            <span>0</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($salarie->PaymentHistory($salarie->employee_id,$salarie->month,$salarie->year)): ?>
                                            <?php echo e($salarie->PaymentHistory($salarie->employee_id,$salarie->month,$salarie->year)->kollan_trust??0); ?>

                                            <?php
                                                $gross_salary -=$salarie->PaymentHistory($salarie->employee_id,$salarie->month,$salarie->year)->kollan_trust??0;
                                            ?>
                                        <?php else: ?>
                                            <span>0</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php echo e($salarie->deduction + ($salarie->loan??0) + ($salarie->PaymentHistory($salarie->employee_id,$salarie->month,$salarie->year)->miscellaneous??0)+
                                                ($salarie->PaymentHistory($salarie->employee_id,$salarie->month,$salarie->year)->revenue_stamp??0)+
                                                ($salarie->PaymentHistory($salarie->employee_id,$salarie->month,$salarie->year)->income_tex??0)+
                                                ($salarie->PaymentHistory($salarie->employee_id,$salarie->month,$salarie->year)->penalty??0)+
                                                ($salarie->PaymentHistory($salarie->employee_id,$salarie->month,$salarie->year)->kollan_trust??0)); ?>

                                    </td>
                                    <td><?php echo e($gross_salary - ($salarie->deduction + $salarie->loan??0)); ?></td>
                                    <td><span class="btn btn-danger">Not Payment</span></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </table>
                        </div>
                    </div>
                </div>
            </section>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- bootstrap datepicker -->
    <script src="<?php echo e(asset('themes/backend/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>

    <script>
        $(function () {
            //Date picker
            $('#start, #end').datepicker({
                autoclose: true,
                format: 'yyyy-mm-dd'
            });
        });

        $('#year').change(function () {
            var year = $(this).val();
            $('#month').html('<option value="">Select Month</option>');

            if (year != '') {
                $.ajax({
                    method: "GET",
                    url: "<?php echo e(route('get_month')); ?>",
                    data: { year: year }
                }).done(function( response ) {
                    $.each(response, function( index, item ) {
                        $('#month').append('<option value="'+item.id+'">'+item.name+'</option>');
                    });
                });
            }
        });

        var APP_URL = '<?php echo url()->full(); ?>';
        function getprint(print) {

            $('body').html($('#'+print).html());
            window.print();
            window.location.replace(APP_URL)
        }
    </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\logic\resources\views/payroll/employee_payment_history/index.blade.php ENDPATH**/ ?>