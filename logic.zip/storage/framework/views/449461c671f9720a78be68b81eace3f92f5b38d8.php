<?php $__env->startSection('title'); ?>
    Employee List
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-body">
                    <form action="<?php echo e(route('report.employee_list')); ?>">
                        <div class="row">

                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-body">
                    <button class="pull-right btn btn-primary" onclick="getprint('prinarea')">Print</button><br><br>

                    <div id="prinarea">
                       <div style="padding:10px; width:100%; text-align:center;">
                            <h2><?php echo e(config('app.name')); ?></h2>
                            <h4>Corporate Office : Plot # 314/A, Road # 18, Block # E , Bashundhara R/A, Dhaka-1229</h4>
                           <h4>
                               <?php if(request()->get('category')==1): ?>
                                   Dhaka Office Employees
                               <?php elseif(request()->get('category')==2): ?>
                                   Factory Employees
                               <?php elseif(request()->get('category')==''): ?>
                                   Dhaka Office and Factory Employees
                               <?php endif; ?>
                           </h4>
                        </div>
                         <table id="table" class="table table-bordered table-striped">
                             <thead>
                             <tr >
                                 <th class="text-center">ID</th>
                                 <th class="text-center">Name</th>
                                 <th class="text-center">Designation</th>
                                 <th class="text-center">Department</th>
                                 <th class="text-center">Mobile</th>
                                 <th class="text-center">Employee Type</th>

                             </tr>
                             </thead>
                             <tbody>
                             <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <tr>
                                     <td class="text-center"><?php echo e($employee->employee_id); ?></td>
                                     <td class="text-center"><?php echo e($employee->name); ?></td>
                                     <td class="text-center"><?php echo e($employee->designation->name); ?></td>
                                     <td class="text-center"><?php echo e($employee->department->name); ?></td>
                                     <td class="text-center"><?php echo e($employee->mobile_no); ?></td>
                                     <td class="text-center">
                                         <?php if($employee->employee_type== 1): ?>
                                         <span class="label label-success">Permanent</span>
                                         <?php else: ?>
                                         <span class="label label-warning">Temponary</span>

                                         <?php endif; ?>

                                     </td>
                                 </tr>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             </tbody>
                         </table>

                     </div>

                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>


        var APP_URL = '<?php echo url()->full(); ?>';
        function getprint(prinarea) {

            $('body').html($('#'+prinarea).html());
            window.print();
            window.location.replace(APP_URL)
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/itautoma/public_html/logic/resources/views/report/employee_list.blade.php ENDPATH**/ ?>