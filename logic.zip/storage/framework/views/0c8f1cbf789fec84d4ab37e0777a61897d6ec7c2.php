<?php $__env->startSection('style'); ?>
    <style>
        #receipt-content{
            font-size: 18px;
        }

        .table-bordered>thead>tr>th, .table-bordered>tbody>tr>th, .table-bordered>tfoot>tr>th, .table-bordered>thead>tr>td, .table-bordered>tbody>tr>td, .table-bordered>tfoot>tr>td {
            border: 1px solid black !important;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    Transaction Details
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row" id="receipt-content">
        <div class="col-md-12">
            <div class="box">
                <div class="box-body">
                    <div class="row">
                        <div class="col-md-12 text-right">
                            <a target="_blank" href="<?php echo e(route('transaction.print', ['transaction' => $transaction->id])); ?>" class="btn btn-primary">Print</a>
                        </div>
                    </div>

                    <hr>

                    <div class="row">
                        <div class="col-xs-4">
                            <img src="<?php echo e(asset('img/logo.png')); ?>" height="50px" style="float: left">
                            <h2 style="margin: 0px; float: left">RECEIPT</h2>
                        </div>

                        <div class="col-xs-4 text-center">
                            <b>Date: </b> <?php echo e($transaction->date->format('j F, Y')); ?>

                        </div>

                        <div class="col-xs-4 text-right">
                            <b>No: </b> <?php echo e($transaction->id + 1000); ?>

                        </div>
                    </div>

                    <div class="row" style="margin-top: 20px">
                        <div class="col-xs-12">
                            <table class="table table-bordered">
                                <tr>
                                    <th width="20%">For Payment of</th>
                                    <td>
                                        <?php echo e($transaction->accountHeadType->name.' - '.$transaction->accountHeadSubType->name); ?>

                                    </td>
                                    <th width="10%">Amount</th>
                                    <td width="15%">৳<?php echo e(number_format($transaction->amount, 2)); ?></td>
                                </tr>

                                <tr>
                                    <th>Amount (In Word)</th>
                                    <td colspan="3"><?php echo e($transaction->amount_in_word); ?></td>
                                </tr>

                                <tr>
                                    <th>Paid By</th>
                                    <td colspan="3">
                                        <?php if($transaction->transaction_method == 1): ?>
                                            Cash
                                        <?php elseif($transaction->transaction_method == 3): ?>
                                            Mobile Banking
                                        <?php else: ?>
                                            Bank - <?php echo e($transaction->bank->name.' - '.$transaction->branch->name.' - '.$transaction->account->account_no); ?>

                                        <?php endif; ?>
                                    </td>
                                </tr>

                                <?php if($transaction->transaction_method == 2): ?>
                                    <tr>
                                        <th>Cheque No.</th>
                                        <td colspan="3"><?php echo e($transaction->cheque_no); ?></td>
                                    </tr>
                                <?php endif; ?>

                                <tr>
                                    <th>Note</th>
                                    <td colspan="3"><?php echo e($transaction->note); ?></td>
                                </tr>

                                <?php if($transaction->transaction_method == 2): ?>
                                    <tr>
                                        <th>Cheque Image</th>
                                        <td colspan="3" class="text-center">
                                            <img src="<?php echo e(asset($transaction->cheque_image)); ?>" height="300px">
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\logic_group\resources\views/accounts/transaction/details.blade.php ENDPATH**/ ?>