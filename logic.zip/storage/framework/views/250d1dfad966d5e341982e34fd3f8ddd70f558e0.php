<?php $__env->startSection('content'); ?>
    <?php $__env->startSection('style'); ?>
    <?php $__env->stopSection(); ?>
    <div class="row">
        <div class="col-md-12">
            <!-- Custom Tabs -->
            <div class="nav-tabs-custom">
                <ul class="nav nav-tabs">
                    <li class="active"><a href="#profile" data-toggle="tab">Appointment Letter</a></li>
                    
                    
                    
                </ul>

                <div class="tab-content">

                    <div class="tab-pane active" id="profile">
                        <button class="pull-right btn btn-primary" onclick="getprint('prinarea_profile')">Print</button><br>

                        <div class="row" id="prinarea_profile" style="margin-left: 30px;">

                            <table class="table table-bordered"  >

                                <tr style="height: 100%;width: 100%">
                                    <div class="row">
                                        <div class="col-xs-2">
                                            <div class="logo" style="margin-top: 26px;margin-left: 22px;">
                                                <div class="logo-img">
                                                    <img src="<?php echo e(asset('img/logo.png')); ?>" alt="" height="120px" width="120px">
                                                </div>

                                            </div>
                                        </div>
                                        <div class="col-xs-10">
                                            <div class="heading">
                                                <strong><h1 style="color: #00B050;font-family: broadway; font-size: 43px;">LOGIC</h1></strong>
                                                <strong><h1 style="color:#FF0000;font-family: times-new-roman;font-size: 33px;">ENGINEERING LIMITED</h1></strong>
                                            </div>
                                        </div>
                                    </div>
                                </tr>
                                <hr style="margin-right: 16px;border-top: 4px solid #B898D0;">

                                <tr>
                                    <div class="row">
                                        <div class="col-xs-4">
                                            <p><?php echo e($candidate->hr); ?></p>
                                            <p><?php echo e($candidate->name); ?></p>
                                            <p><?php echo e($candidate->fathers_name); ?></p>
                                            <p><?php echo e($candidate->post_office); ?></p>
                                            <p><?php echo e($candidate->police_station); ?></p>
                                            <p><?php echo e($candidate->villaeg); ?></p>
                                            <p><?php echo e($candidate->district); ?></p>

                                        </div>
                                        <div class="col-xs-3 col-xs-offset-5">
                                            <div class="heading">
                                                <h4><?php echo e(date('d-m-Y', strtotime($candidate->created_at))); ?></h4>

                                            </div>
                                        </div>
                                    </div>
                                </tr>

                                <tr>
                                    <p>subject: <?php echo e($candidate->subject); ?> </p>
                                </tr>
                                <tr>
                                    <h3>Dear <?php echo e($candidate->name); ?></h3>
                                    <div class="body">
                                        <?php echo $candidate->appointment_letter_body; ?>

                                    </div>
                                </tr>
                            </table>
                        </div>
                    </div>
                    <hr style="border-top: 4px solid #B898D0;">

                    <div class="addrea" style="text-align: center;">
                        <?php echo $candidate->address; ?>

                    </div>

                    <table class="table table-bordered" style="" >


                    </table>

                </div>
                <!-- /.tab-content -->
            </div>
            <!-- nav-tabs-custom -->
        </div>
        <!-- /.col -->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>

        var APP_URL = '<?php echo url()->full(); ?>';
        function getprint(prinarea_profile) {

            $('body').html($('#'+prinarea_profile).html());
            window.print();
            window.location.replace(APP_URL)
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\logic_new\resources\views/hr/evalution/appointment_letter.blade.php ENDPATH**/ ?>