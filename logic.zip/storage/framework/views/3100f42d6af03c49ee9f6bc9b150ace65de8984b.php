<?php $__env->startSection('style'); ?>
    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo e(asset('themes/backend/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
    <!-- bootstrap datepicker -->
    <link rel="stylesheet" href="<?php echo e(asset('themes/backend/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themes/backend/plugins/timepicker/bootstrap-timepicker.min.css')); ?>">
    <!-- bootstrap datepicker -->
    <link rel="stylesheet" href="<?php echo e(asset('themes/backend/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>">

    <style>
        .timepicker_wrap{
            width: max-content;
        }
    </style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    Employee Attendance Process
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php if(Session::has('message')): ?>
        <div class="alert alert-success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <?php echo e(Session::get('message')); ?>

        </div>
    <?php endif; ?>

    <?php if(Session::has('error')): ?>
        <div class="alert alert-danger alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <?php echo e(Session::get('error')); ?>

        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-body">
                    <form method="POST" action="<?php echo e(route('employee.attendance.process')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-1">
                                <label for="process_date">Date</label>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <input id="attend_date" value="<?php echo e(old('process_date')); ?>" name="process_date" type="text" class="form-control" autocomplete="off">
                                    <span class="text-danger"><?php echo e($errors->first('process_date')); ?></span>
                                </div>
                            </div>

                            <div class="col-md-3">
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary form-control">Attendance Process</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <div class="box">

                <table id="table" class="table table-bordered  ">
                    <thead>
                    <tr>
                        <th>Sl No.</th>
                        <th>Name</th>
                        <th>Designation</th>
                        <th>Department</th>
                        <th>Present/Absent</th>
                        <th>Present Date</th>
                        <th>Intime</th>
                        <th>Outtime</th>
                        <th>Total Hours</th>
                        <th>LateTime</th>
                        <th>OverTime</th>
                        <th>Note</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php if($employees): ?>
                        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="item">
                                <tr>
                                    <td><?php echo e($employee->employee_id); ?></td>
                                    <td><?php echo e($employee->employee->name); ?></td>
                                    <td><?php echo e($employee->employee->department->name); ?></td>
                                    <td><?php echo e($employee->employee->designation->name); ?></td>
                                    <td>
                                        <?php if($employee->status == 1): ?>
                                            Present
                                        <?php else: ?>
                                            Absent
                                        <?php endif; ?>

                                    </td>
                                    <td><?php echo e($employee->process_date); ?></td>
                                    <?php if($employee->intime): ?>
                                        <td><?php echo e((date('H:i:s', strtotime($employee->intime)))); ?></td>
                                    <?php endif; ?>
                                    <?php if($employee->intime): ?>
                                        <td><?php echo e((date('H:i:s', strtotime($employee->outtime)))); ?></td>
                                    <?php endif; ?>
                                    <?php if($employee->intime): ?>
                                        <td><?php echo e((date('H:i:s', strtotime($employee->total_hours??'')))); ?></td>
                                    <?php endif; ?>
                                    <?php if($employee->intime): ?>
                                        <td><?php echo e((date('H:i:s', strtotime($employee->late_time)))); ?></td>
                                    <?php endif; ?>
                                    <?php if($employee->intime): ?>
                                        <td><?php echo e((date('H:i:s', strtotime($employee->over_time)))); ?></td>
                                    <?php endif; ?>
                                    <td><?php echo e($employee->note); ?></td>

                                </tr>
                            </span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- DataTables -->
    <script src="<?php echo e(asset('themes/backend/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('themes/backend/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
    <!-- bootstrap datepicker -->
    <script src="<?php echo e(asset('themes/backend/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('themes/backend/plugins/timepicker/bootstrap-timepicker.min.js')); ?>"></script>
    <!-- sweet alert 2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>s

    <script>
        //Date picker
        $('#attend_date').datepicker({
            autoclose: true,
            format: 'yyyy-mm-dd',
            orientation: 'bottom'
        });

        //Timepicker
        $('.timepicker').timepicker({
            showInputs: false,
            defaultTime: null
        });


        //$('.present_time').prop( "disabled", true );

        $(".present_check").change(function () {
            var check =$(this)
            if ($(this).prop('checked')) {
                check.closest('tr').find('.present_time').prop( "disabled", false );
            }else{
                check.closest('tr').find('.present_time').prop( "disabled", true ).val(' ');

            }
        });

        $(".late_check").change(function () {
            var check =$(this)
            if ($(this).prop('checked')) {
                check.closest('tr').find('.late_time').prop( "disabled", false );
            }else{
                check.closest('tr').find('.late_time').prop( "disabled", true ).val(' ');

            }
        });
        $(".late_check").trigger("change")

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/itautoma/public_html/logic/resources/views/hr/attendance/process.blade.php ENDPATH**/ ?>