<?php $__env->startSection('style'); ?>
    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo e(asset('themes/backend/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    Candidate Details
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <!-- Custom Tabs -->
            <div class="nav-tabs-custom">
                <ul class="nav nav-tabs">
                    <li class="active"><a href="#profile" data-toggle="tab">Candidate Profile</a></li>



                </ul>

                <div class="tab-content">

                    <div class="tab-pane active" id="profile">
                        <button class="pull-right btn btn-primary" onclick="getprint('prinarea_profile')">Print</button><br>

                        <div class="row" id="prinarea_profile">
                            <div class="col-md-8">
                                <table class="table table-bordered" >
                                    <tr>
                                        <th>Name</th>
                                        <td><?php echo e($candidate->name); ?></td>
                                    </tr>

                                    <tr>
                                        <th>Fathers Name</th>
                                        <td><?php echo e($candidate->fathers_name); ?></td>
                                    </tr>

                                    <tr>
                                        <th>ID</th>
                                        <td><?php echo e($candidate->id); ?></td>
                                    </tr>
                                    <tr>
                                    </tr>

                                    <tr>
                                        <th>Interview Date</th>
                                        <td>
                                            <?php if($candidate->interview_date!=null): ?>
                                                <?php echo e($candidate->interview_date); ?>

                                            <?php endif; ?>
                                        </td>
                                    </tr>

                                    <tr>
                                        <th>Expected Joining Date</th>
                                        <td>
                                            <?php if($candidate->expected_joining_date!=null): ?>
                                                <?php echo e($candidate->expected_joining_date); ?>

                                            <?php endif; ?>


                                        </td>
                                    </tr>

                                    <tr>
                                        <th>Department</th>
                                        <td><?php echo e($candidate->department->name); ?></td>
                                    </tr>

                                    <tr>
                                        <th>Designation</th>
                                        <td><?php echo e($candidate->designation->name); ?></td>
                                    </tr>


                                    <tr>
                                        <th>Mobile No.</th>
                                        <td><?php echo e($candidate->mobile_no); ?></td>
                                    </tr>


                                    <tr>
                                        <th>Email</th>
                                        <td><?php echo e($candidate->email); ?></td>
                                    </tr>

                                    <tr>
                                        <th>Current Salary</th>
                                        <td><?php echo e(number_format($candidate->current_salaray,2)); ?></td>
                                    </tr>

                                    <tr>
                                        <th>Expected Salary</th>
                                        <td><?php echo e(number_format($candidate->expected_salary,2)); ?></td>
                                    </tr>

                                    <tr>
                                        <th>Salary_Offered</th>
                                        <td><?php echo e(number_format($candidate->salary_offered,2)); ?></td>
                                    </tr>

                                    <tr>
                                        <th>Other Benefits</th>
                                        <td><?php echo e($candidate->other_benefits); ?></td>
                                    </tr>

                                    <tr>
                                        <th>Any Condition</th>
                                        <td><?php echo e($candidate->any_condition); ?></td>
                                    </tr>

                                    <tr>
                                        <th>required_company_unit</th>
                                        <td><?php echo e($candidate->required_company_unit); ?></td>
                                    </tr>

                                    <tr>
                                        <th>Job_Description</th>
                                        <td><?php echo e($candidate->job_description); ?></td>
                                    </tr>

                                    <tr>
                                        <th>Reference</th>
                                        <td><?php echo e($candidate->reference); ?></td>
                                    </tr>

                                </table>
                            </div>

                        </div>
                    </div>
                </div>
                <!-- /.tab-content -->
            </div>
            <!-- nav-tabs-custom -->
        </div>
        <!-- /.col -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- DataTables -->
    <script src="<?php echo e(asset('themes/backend/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('themes/backend/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>

















    <script>

        var APP_URL = '<?php echo url()->full(); ?>';
        function getprint(prinarea_profile) {

            $('body').html($('#'+prinarea_profile).html());
            window.print();
            window.location.replace(APP_URL)
        }
        function getprintleave(prinarea_leave) {

            $('body').html($('#'+prinarea_leave).html());
            window.print();
            window.location.replace(APP_URL)
        }
        function getprintleave(prinarea_salary) {

            $('body').html($('#'+prinarea_salary).html());
            window.print();
            window.location.replace(APP_URL)
        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/itautoma/public_html/logic/resources/views/hr/evalution/details.blade.php ENDPATH**/ ?>