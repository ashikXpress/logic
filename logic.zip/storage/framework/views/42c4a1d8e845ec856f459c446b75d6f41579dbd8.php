<?php $__env->startSection('style'); ?>
    <!-- bootstrap datepicker -->
    <link rel="stylesheet" href="<?php echo e(asset('themes/backend/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>">
    <!-- Select2 -->
    <link rel="stylesheet" href="<?php echo e(asset('themes/backend/bower_components/select2/dist/css/select2.min.css')); ?>">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    Holiday Add
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">

                    <h3 class="box-title">Holiday Information</h3>
                </div>
                <!-- /.box-header -->

                <div class="box-body">
                    <form action="<?php echo e(route('payroll.holiday_add')); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group <?php echo e($errors->has('name') ? 'has-error' :''); ?>">
                                    <label>Holiday Name</label>
                                    <input type="text" class="form-control" placeholder="Enter Name"
                                           name="name" value="<?php echo e(old('name')); ?>">

                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="help-block"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                            </div>
                            <div class="col-md-3">
                                <div class="form-group <?php echo e($errors->has('from') ? 'has-error' :''); ?>">
                                    <label>From</label>

                                    <div class="input-group date">
                                        <div class="input-group-addon">
                                            <i class="fa fa-calendar"></i>
                                        </div>
                                        <input type="text" class="form-control pull-right"
                                               id="from" name="from"
                                               value="<?php echo e(date('Y-m-d')); ?>"
                                               autocomplete="off" data-date-end-date="<?php echo e(date('Y-12-31')); ?>"
                                               data-date-start-date="<?php echo e(date('Y-01-01')); ?>" >

                                    </div>
                                    <?php $__errorArgs = ['from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="help-block"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <!-- /.input group -->
                                </div>
                            </div>

                            <div class="col-md-3">
                                <div class="form-group <?php echo e($errors->has('to') ? 'has-error' :''); ?>">
                                    <label>To</label>

                                    <div class="input-group date">
                                        <div class="input-group-addon">
                                            <i class="fa fa-calendar"></i>
                                        </div>
                                        <input type="text" class="form-control pull-right"
                                               id="to" name="to"
                                               value="<?php echo e(date('Y-m-d')); ?>"
                                               autocomplete="off" data-date-end-date="<?php echo e(date('Y-12-31')); ?>"
                                               data-date-start-date="<?php echo e(date('Y-01-01')); ?>">

                                    </div>
                                    <!-- /.input group -->
                                    <?php $__errorArgs = ['to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="help-block"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-2">
                                <div class="form-group">
                                    <label>	&nbsp;</label>

                                    <input class="btn btn-primary form-control" type="submit" value="Submit">
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- Select2 -->
    <script src="<?php echo e(asset('themes/backend/bower_components/select2/dist/js/select2.full.min.js')); ?>"></script>
    <!-- bootstrap datepicker -->
    <script src="<?php echo e(asset('themes/backend/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>

    <script>

        $(function () {
            //Date picker
            $('#from, #to').datepicker({
                autoclose: true,
                format: 'yyyy-mm-dd',
                orientation: 'bottom'
            });

            //Initialize Select2 Elements
            $('.select2').select2();
        });


    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\logic_group\resources\views/payroll/holiday/add.blade.php ENDPATH**/ ?>