<?php $__env->startSection('style'); ?>
    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo e(asset('themes/backend/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    Candidate Details
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(Session::has('message')): ?>
        <div class="alert alert-success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <?php echo e(Session::get('message')); ?>

        </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-12">
            <!-- Custom Tabs -->
            <div class="nav-tabs-custom">
                <ul class="nav nav-tabs">
                    <li><a href="<?php echo e(route('candidate_evalution_form.details',['candidate' => $candidate->id])); ?>">Personal Information</a></li>
                    <li><a href="<?php echo e(route('academic_and_training.details', ['candidate' => $candidate->id])); ?>">Academic & Training</a></li>
                    <li class="active"><a href="<?php echo e(route('job_information.details',['candidate' => $candidate->id])); ?>">Job Information</a></li>
                    <li><a href="<?php echo e(route('employee_wise_attendance',['candidate' => $candidate->id])); ?>">Attendance</a></li>
                    <li><a href="<?php echo e(route('payroll.employee_wise.leave',['candidate' => $candidate->id])); ?>">Leave</a></li>
                    <li><a href="<?php echo e(route('payroll.employee.wise.salary.slip',['candidate' => $candidate->id])); ?>">Salary</a></li>
                    <li><a href="<?php echo e(route('payroll.employee.wise.loan',['candidate' => $candidate->id])); ?>">Loan</a></li>
                    <li><a href="<?php echo e(route('candidate_evaluation',['candidate' => $candidate->id])); ?>">Evalution</a></li>
                    <li><a href="#userAccount">User Account</a></li>
                    <li><a href="<?php echo e(route('payroll.employee_wise.report',['candidate' => $candidate->id])); ?>">Report</a></li>
                </ul>

                <div class="tab-content">

                    <div class="tab-pane active" id="profile">
                        <button class="pull-right btn btn-primary" onclick="getprint('prinarea_profile')">Print</button><br>

                        <u><h4 class="text-center">Previous Job Information</h4></u>
                        <div class="row" id="prinarea_profile">
                            <div class="col-md-12">
                                <table class="table table-bordered">
                                    <tr>
                                        <th>SL</th>
                                        <th>Previous Company Name</th>
                                        <th>Previous Company Designation</th>
                                        <th>Previous Job Duration From</th>
                                        <th>Duration To</th>
                                        <th>Total Duration</th>
                                        <th>Major Responsibility</th>
                                        <th>Experience Certificate</th>
                                        <th class="text-center">Action</th>

                                    </tr>

                                    <?php $__currentLoopData = $jobInformations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobInformation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr>
                                        <td><?php echo e($jobInformation->employee_id??''); ?></td>
                                        <td><?php echo e($jobInformation->previous_company_name??''); ?></td>
                                        <td><?php echo e($jobInformation->previous_company_designation??''); ?></td>
                                        <td><?php echo e($jobInformation->from??''); ?></td>
                                        <td><?php echo e($jobInformation->to??''); ?></td>
                                        <td><?php echo e($jobInformation->total_duration??''); ?></td>
                                        <td><?php echo e($jobInformation->major_responsibility??''); ?></td>

                                        <td>
                                            <img src="<?php echo e(asset($jobInformation->experience_certificate??'')); ?>" alt="" height="50" width="50">
                                        </td>
                                        <td>
                                            <a class="btn btn-info btn-sm" href="<?php echo e(route('employee_wise_job_information.add',['jobInformation' => $jobInformation->id])); ?>">Add New</a>
                                            <a class="btn btn-info btn-sm" href="<?php echo e(route('employee_wise_job_information.edit',['jobInformation' => $jobInformation->id])); ?>">Edit</a>
                                            <a class="btn btn-danger btn-sm btn-delete" role="button" data-id="<?php echo e($jobInformation->id); ?>">Delete</a>
                                        </td>

                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            </div>
                        </div>

                        <u><h4 class="text-center">Current Job</h4></u>
                        <div class="row" id="prinarea_profile">
                            <div class="col-md-5">
                                <table class="table table-bordered">
                                    <tr>
                                        <th>SL</th>
                                        <th>Particulars</th>
                                        <th>Data</th>
                                    </tr>

                                    <tr>
                                        <td>1</td>
                                        <td>Concern Name</td>
                                        <td>Logic Engineering Limited</td>


                                    </tr>
                                    <tr>
                                        <td>2</td>
                                        <td>Employee Name</td>
                                        <td><?php echo e($candidate->name??''); ?></td>
                                    </tr>
                                    <tr>
                                        <td>3</td>
                                        <td>Designation</td>
                                        <td><?php echo e($candidate->designation->name??''); ?></td>
                                    </tr>
                                    <tr>
                                        <td>4</td>
                                        <td>Grade</td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td>5</td>
                                        <td>Joining Date</td>
                                        <td><?php echo e($candidate->expected_joining_date??''); ?></td>
                                    </tr>
                                    <tr>
                                        <td>6</td>
                                        <td>Resignation</td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td>7</td>
                                        <td>Duration</td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td>8</td>
                                        <td>Joining Salary</td>
                                        <td><?php echo e($candidate->expected_salary??''); ?></td>
                                    </tr>
                                    <tr>
                                        <td>9</td>
                                        <td>Job Description</td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td>10</td>
                                        <td>Promotion</td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td>11</td>
                                        <td>Present Salary</td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td>12</td>
                                        <td>Evalution</td>
                                        <td></td>
                                    </tr>

                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.tab-content -->
            </div>
            <!-- nav-tabs-custom -->
        </div>
        <!-- /.col -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- DataTables -->
    <script src="<?php echo e(asset('themes/backend/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('themes/backend/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
    <script>

        var APP_URL = '<?php echo url()->full(); ?>';
        function getprint(prinarea_profile) {

            $('body').html($('#'+prinarea_profile).html());
            window.print();
            window.location.replace(APP_URL)
        }

        $(function () {
            $('body').on('click', '.btn-delete', function (e) {
                e.preventDefault();
                var jobInformationId = $(this).data('id');

                Swal.fire({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Confirm deleted !'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            method: "get",
                            url: "<?php echo e(route('employee_wise_job_information.delete')); ?>",
                            data: { jobInformationId: jobInformationId }
                        }).done(function( response ) {
                            if (response.success) {
                                Swal.fire(
                                    'Deleted!',
                                    response.message,
                                    'success'
                                ).then((result) => {
                                    location.reload();
                                    //window.location.href = response.redirect_url;
                                });
                            } else {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Oops...',
                                    text: response.message,
                                });
                            }
                        });

                    }
                })

            });
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/itautoma/public_html/logic/resources/views/hr/job_information/details.blade.php ENDPATH**/ ?>